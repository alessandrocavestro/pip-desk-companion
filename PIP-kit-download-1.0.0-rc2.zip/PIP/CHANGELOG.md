# Changelog

## 1.0.0-rc2 - 18 novembre 2026

- Base sostituita con gli effettivi sorgenti **Studio 1.5 precedenti all'integrazione Corsa**, su indicazione del titolare. La candidata precedente, ricavata da Studio Corsa, è ritirata e conservata nel supporto.
- Riportata sulla v1.5 la sola correzione del movimento: riferimento IMU/riarmo dopo il riposo, niente reinnesco da cambio posa e self-test accelerometro esplicitamente disabilitato. Le altre modifiche successive alla v1.5 non sono state importate.
- Nessuna integrazione Corsa presente nella base scelta.
- Preferenze isolate nel namespace `pip_public`; primo avvio da configurare autonomamente.
- Agenda Google facoltativa: calendario principale dell'utente come default, etichette generiche e validazione UTF-8/limiti mantenuta.
- Case v24 invariato rispetto ai file stampati: nuovo nome di consegna, identici contenuti e impostazioni.
- Aggiunte distinta, montaggio, installazione, uso, case study e crediti.

Aggiornamento della documentazione della stessa candidata: fotografie reali senza dati privati, guida illustrata PDF, case study con il difetto del movimento e stato delle prove hardware aggiornato. Nessuna modifica al firmware o al case.

La numerazione del firmware pubblico riparte da 1.0.0; v24 è la revisione del case, non il numero del firmware. RC significa candidata al rilascio, non versione stabile già provata sul dispositivo.
