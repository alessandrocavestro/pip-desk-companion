// PIP Agenda v1 — solo lettura. Non aggiungere editor a questo progetto.
const PIP_CALENDARS = [
  {id: 'primary', label: 'Personale'}
];
const PIP_DAYS = 7;

function inizializzaPip() {
  verificaAccesso();
  const props = PropertiesService.getScriptProperties();
  if (!props.getProperty('PIP_DEVICE_TOKEN')) {
    props.setProperty('PIP_DEVICE_TOKEN', nuovaChiave_());
  }
  console.log('Pronto. Copia PIP_DEVICE_TOKEN dalle Proprietà script nelle impostazioni di PIP. Conservalo privatamente.');
}

function verificaAccesso() {
  PIP_CALENDARS.forEach(source => {
    const calendar = (source.id === 'primary' ? CalendarApp.getDefaultCalendar() : CalendarApp.getCalendarById(source.id));
    if (!calendar) throw new Error('Un calendario non è accessibile. Controlla l’account Google.');
    calendar.getEvents(new Date(), new Date(Date.now() + 60000));
  });
  console.log('Lettura dei calendari selezionati riuscita. Nessun evento modificato.');
}

function rigeneraChiavePip() {
  PropertiesService.getScriptProperties().setProperty('PIP_DEVICE_TOKEN', nuovaChiave_());
  CacheService.getScriptCache().remove('pip-agenda-v1');
  console.log('Vecchia chiave revocata. Copia la nuova PIP_DEVICE_TOKEN nelle impostazioni di PIP.');
}

function nuovaChiave_() {
  return (Utilities.getUuid() + Utilities.getUuid()).replace(/-/g, '').toLowerCase();
}

function risposta_(value) {
  return ContentService.createTextOutput(JSON.stringify(value)).setMimeType(ContentService.MimeType.JSON);
}

function doGet() {
  // Il browser non riceve appuntamenti né chiavi, neanche se conosce l'URL.
  return risposta_({ok: false, version: 1, error: 'use_post'});
}

function chiaviUguali_(a, b) {
  if (typeof a !== 'string' || typeof b !== 'string') return false;
  if (!/^[a-f0-9]{64}$/.test(a || '') || !/^[a-f0-9]{64}$/.test(b || '')) return false;
  let diff = 0;
  for (let i = 0; i < 64; ++i) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

function doPost(e) {
  let request;
  try {
    const body = e && e.postData && e.postData.contents;
    if (!body || body.length > 160) return risposta_({ok: false, version: 1, error: 'unauthorized'});
    request = JSON.parse(body);
  } catch (_) {
    return risposta_({ok: false, version: 1, error: 'unauthorized'});
  }
  const expected = PropertiesService.getScriptProperties().getProperty('PIP_DEVICE_TOKEN');
  if (!chiaviUguali_(request && request.token, expected)) {
    return risposta_({ok: false, version: 1, error: 'unauthorized'});
  }
  // Autenticare PRIMA di leggere anche la cache.
  try {
    const cache = CacheService.getScriptCache();
    const cached = cache.get('pip-agenda-v1');
    if (cached) return ContentService.createTextOutput(cached).setMimeType(ContentService.MimeType.JSON);
    const now = Math.floor(Date.now() / 1000);
    const items = [];
    PIP_CALENDARS.forEach(source => {
      const calendar = (source.id === 'primary' ? CalendarApp.getDefaultCalendar() : CalendarApp.getCalendarById(source.id));
      if (!calendar) throw new Error('calendar_unavailable');
      calendar.getEvents(new Date(now * 1000), new Date((now + PIP_DAYS * 86400) * 1000)).forEach(event => {
        if (event.getMyStatus() === CalendarApp.GuestStatus.NO) return;
        items.push({
          uid: event.getId(), title: event.getTitle(), source: source.label,
          start: Math.floor(event.getStartTime().getTime() / 1000),
          end: Math.floor(event.getEndTime().getTime() / 1000),
          all_day: event.isAllDayEvent()
        });
      });
    });
    const events = unisciEventi_(items, now).map(item => {
      const digest = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, item.key, Utilities.Charset.UTF_8);
      const id = digest.slice(0, 12).map(byte => ('0' + ((byte + 256) % 256).toString(16)).slice(-2)).join('');
      return {id: id, title: item.title, source: item.source, start: item.start, end: item.end, all_day: item.all_day};
    });
    const result = {ok: true, version: 1, generated: now, until: now + PIP_DAYS * 86400, events: events};
    const json = JSON.stringify(result);
    cache.put('pip-agenda-v1', json, 60);
    return ContentService.createTextOutput(json).setMimeType(ContentService.MimeType.JSON);
  } catch (_) {
    // Non mascherare il fallimento di un calendario con un'agenda parziale o vuota.
    // Niente titoli, URL, indirizzi o token nei log/risposte di errore.
    return risposta_({ok: false, version: 1, error: 'calendar_unavailable'});
  }
}

function unisciEventi_(items, now) {
  const byKey = new Map();
  items.forEach(item => {
    if (!Number.isFinite(item.start) || !Number.isFinite(item.end) || item.end <= now ||
        item.end <= item.start || item.start >= now + PIP_DAYS * 86400) return;
    // Lo stesso UID può avere molte ricorrenze: l'inizio distingue le occorrenze.
    // Due eventi distinti con lo stesso titolo/orario restano distinti.
    const key = item.uid + '|' + item.start + '|' + item.end;
    const previous = byKey.get(key);
    if (previous) {
      if (previous.source !== item.source) previous.source = 'Più calendari';
      if (previous.title === 'Impegno' && item.title) previous.title = pulisciTitolo_(item.title);
      return;
    }
    byKey.set(key, {key: key, title: pulisciTitolo_(item.title), source: item.source,
      start: item.start, end: item.end, all_day: !!item.all_day});
  });
  const sorted = Array.from(byKey.values()).sort((a, b) => a.start - b.start || a.end - b.end || a.key.localeCompare(b.key));
  // Riserva spazio agli appuntamenti con orario; gli eventi giornalieri non li nascondono.
  return sorted.filter(item => !item.all_day).slice(0, 16)
    .concat(sorted.filter(item => item.all_day).slice(0, 4))
    .sort((a, b) => a.start - b.start || a.end - b.end || a.key.localeCompare(b.key));
}

function pulisciTitolo_(value) {
  const title = String(value || '').replace(/[\u0000-\u001f\u007f]/g, ' ').replace(/\s+/g, ' ').trim();
  // Firmware: 121 byte UTF-8, incluso il terminatore. Non spezzare una lettera.
  let result = '', bytes = 0;
  for (const c of Array.from(title || 'Impegno')) {
    const point = c.codePointAt(0);
    const size = point < 0x80 ? 1 : point < 0x800 ? 2 : point < 0x10000 ? 3 : 4;
    if (point >= 0xd800 && point <= 0xdfff) continue;
    if (bytes + size > 120) break;
    result += c; bytes += size;
  }
  return result || 'Impegno';
}
