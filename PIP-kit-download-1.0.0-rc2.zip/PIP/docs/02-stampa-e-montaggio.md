# 2. Stampa e montaggio

## Prima della stampa

Installa il firmware e prova il display sulla scheda fuori dal contenitore. Controlla che scheda, distanziali e cavo siano quelli della [distinta](01-componenti.md).

Apri `hardware/3MF/PIP-v24-A1-PETG.3mf` **come progetto** in Bambu Studio. Contiene tutti e tre i pezzi, su un piatto: non occorre dividere il modello o acquistare AMS. Usa scala 100% e mantieni l'orientamento.

| Impostazione del riferimento provato | Valore |
|---|---|
| Stampante / ugello / piatto | Bambu Lab A1 / 0,4 mm / PEI testurizzato |
| Materiale | SUNLU PETG Trasparente Bianco 1,75 mm |
| Ugello / piatto | 240 °C / 70 °C |
| Altezza strato / pareti / riempimento | 0,20 mm / 3 / 20% |
| Velocità parete esterna | 30 mm/s |
| Portata volumetrica massima | 6 mm³/s |
| Supporti / brim | Disattivati / disattivato |
| Stima slicer | circa 1 h 32 min e 15 g |

Le due facce esterne dei gusci sono sul piatto; il tastino appoggia sul fianco piano. Non ruotare i pezzi su un'altra faccia. Se usi un'altra macchina o un altro filamento, crea e prova un profilo adatto: il download non certifica quella combinazione. Lascia raffreddare il piatto prima di staccare i pezzi. La traslucenza dipende dalla stampa reale; non è un effetto vetro garantito.

![Tavola di montaggio del CAD v24: i colori distinguono i pezzi, non il materiale finale](../assets/montaggio-v24.png)

## Il risultato reale

<img src="../assets/foto-reali/01-PIP-tre-quarti-reale.jpg" alt="Case v24 stampato: vista a tre quarti e filo laterale" width="280" /> <img src="../assets/foto-reali/03-PIP-retro-reale.jpg" alt="Retro reale con i quattro fissaggi della scheda" width="280" />

Fotografie del prototipo di Alessandro. Le quattro teste visibili sul retro sono le M2 della scheda: non sostituiscono le tre M2,5 svasate che chiudono il guscio. Per riconoscere i tre punti di chiusura segui la tavola CAD e la sequenza qui sotto. Le foto dell'interno aperto non sono ancora incluse.

## Riconosci i pezzi

- **F24 / corpo**: finestra del display e fianchi con micro-righe.
- **R24 / retro**: quattro appoggi della scheda, pozzi per le viti e tre tasche dei dadi.
- **N24 / tastino**: testa e quattro intagli di riconoscimento. È trattenuto quando il guscio è chiuso.

Ingombro del corpo con righe circa **45,28 x 50 x 20 mm**, esclusi cavo e sporgenza del tastino. Finestra 31,2 x 26,6 mm. Gli STL sono orientati per stampare; gli STEP sono nella posizione di assemblaggio.

## Assembla a dispositivo scollegato

1. Rimuovi soltanto fili o residui liberi. Le parti devono accostarsi con pressione leggera: non usare viti o forza per compensare un incastro bloccato.
2. Inserisci nel retro vuoto i **tre dadi M2,5**: i due inferiori dalle aperture verso il centro, il superiore dalla tasca laterale verso il suo foro. Fallo prima di fissare la scheda.
3. Inserisci la spina a 90° del cavo nella scheda. L'altro capo resta scollegato da computer e alimentatore.
4. Appoggia il gruppo con il vetro su un panno morbido e i distanziali metallici verso l'alto. Accosta R24 ai quattro distanziali; accompagna il filo verso la linguetta di uscita laterale.
5. Inserisci le **quattro M2 x 8** dai pozzi posteriori e serra leggermente. Il retro deve appoggiare senza trascinarlo in posizione con le viti e senza toccare componenti diversi dai punti di appoggio previsti.
6. Gira il gruppo con retro sul panno e display verso l'alto. Inserisci N24 nella guida, con testa e quattro intagli all'esterno e punta rivolta al pulsante PWR reale.
7. Accosta F24 al retro accompagnando il filo nel passaggio laterale. Controlla che il display sia libero e centrato e che il cavo non sia schiacciato.
8. Prima di serrare, prova il tastino: deve dare clic, restare trattenuto a guscio chiuso e tornare libero senza tenere premuto il PWR a riposo.
9. Avvia la **M2,5 x 8 superiore e le due inferiori**, poi serra leggermente alternando i tre punti. Riprova il tasto dopo il serraggio.

Se una vite arriva in battuta prima che il pezzo sia stabile, o il tasto si impunta, riapri e identifica l'interferenza. Non accorciare viti o limare parti alla cieca. Non tirare il cavo per valutare la tenuta: non è stata validata come protezione a strappo.

## Verifica finale

Collega l'alimentazione, controlla avvio, clic singoli e ritorno del tastino. Prova il timer e l'apertura delle impostazioni. Solleva delicatamente il dispositivo con il cavo libero e riappoggialo: una reazione continua da fermo non è il comportamento previsto. Mantieni il cavo rilassato e usa PIP su un piano stabile.
