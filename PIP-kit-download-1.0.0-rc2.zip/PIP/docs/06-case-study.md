# PIP - Dalla chat alla scrivania

> «Può una conversazione diventare un oggetto vero?»

<img src="../assets/foto-reali/02-PIP-frontale-reale.jpg" alt="Il risultato reale: PIP acceso nel suo contenitore trasparente" width="360" />

## La domanda iniziale

Il 3 ottobre 2026 Alessandro Cavestro ha iniziato il progetto con una sfida: riuscire a costruire un piccolo oggetto da scrivania facendosi guidare da ChatGPT, partendo da conoscenze basilari di elettronica.

Il primo riferimento era un mini dispositivo già esistente, Tinytosh. L'obiettivo dichiarato era sviluppare un oggetto personale con una propria forma, senza copiarne l'estetica. Le funzioni iniziali erano semplici: una presenza simpatica, ora e meteo.

## Come abbiamo lavorato

ChatGPT ha proposto alternative, preparato file geometrici e di stampa, scritto il firmware e fornito istruzioni e verifiche. Alessandro ha scelto la direzione, acquistato i componenti, stampato, montato, osservato il dispositivo e fornito fotografie, misure e riscontri.

Il progetto usa una scheda commerciale e librerie esistenti. “Sviluppato con ChatGPT” descrive il processo di progettazione e accompagnamento; non significa che l'AI abbia prodotto l'hardware elettronico, inventato tutte le dipendenze o eseguito le prove fisiche.

## Sei passaggi che raccontano il progetto

### 1. Una scelta di carattere

Fra tre proposte iniziali - PIP, TEO e MOKO - Alessandro ha scelto PIP. Il primo concept era un personaggio morbido con due piedini. Nel tempo la forma è diventata più compatta e minimale, mantenendo la faccina sul display come elemento riconoscibile.

### 2. Prima le tolleranze, poi il guscio

I primi file stampati erano un perno e anelli con giochi diversi. Non erano ancora il prodotto. Le prove hanno dato un riferimento per gli accoppiamenti, seguito da campioni di giunzione, supporti della scheda e finestre del display.

### 3. L'hardware reale cambia il progetto

L'idea iniziale prevedeva una scheda touch; il dispositivo effettivamente usato è una Waveshare ESP32-S3-LCD-1.69 V2 senza touch. Il comando è quindi affidato al pulsante PWR. Misure della scheda, distanziali e cavo hanno guidato i supporti e il percorso dell'USB.

### 4. Le revisioni che non hanno funzionato

Alcune versioni del contenitore avevano problemi concreti: il tastino non raggiungeva il clic o poteva sfilarsi, le sedi dei dadi erano scomode, il cavo interferiva con i fissaggi e una variante risultava troppo grande. I riscontri hanno portato a campioni mirati e alla revisione di guida del tasto, chiusura e fissaggio della scheda.

La sigla v24 identifica una revisione del CAD; non significa che siano stati stampati 24 contenitori completi.

### 5. La finitura finale

Alessandro ha scelto micro-righe sui fianchi e PETG trasparente bianco. Prima sono stati provati piccoli campioni, poi il contenitore completo. Il 13 novembre il riscontro sul v24 è stato “stampato e tutto ok”. Le fotografie incluse mostrano il risultato reale. I render e le rielaborazioni AI restano illustrazioni separate.

### 6. Dal prototipo personale al download

Il software è cresciuto con ora, meteo, timer, agenda e reazione al movimento. Per il download è stata scelta **Studio 1.5**, mantenendo le funzioni di base del compagno da scrivania. Su questa base viene riportata soltanto la correzione del difetto che provocava reazioni continue da fermo. Chi costruisce PIP configura la propria rete e, se desidera, il proprio calendario.

### Un difetto del software risolto con una misura

Il personaggio continuava a reagire anche quando era fermo sulla scrivania. Il software interpretava una differenza costante del sensore come un nuovo gesto. La correzione aggiorna il riferimento dopo il riposo e richiede un nuovo movimento per riattivare la reazione. La traccia rilevata sul dispositivo è stata usata per riprodurre il difetto, poi Alessandro ha confermato la prova fisica di presa e appoggio sulla versione pubblica.

## Che cosa dimostra questo esperimento

Il risultato documenta un percorso di costruzione assistita: l'AI prepara proposte, codice e file, mentre l'oggetto reale mette alla prova quelle proposte. Fotografie, misure e osservazioni del costruttore sono state indispensabili per correggere le ipotesi sbagliate.

Non è un esperimento che dimostra una riuscita automatica da un singolo prompt, né una garanzia che ogni progetto simile richieda lo stesso tempo. È un esempio concreto di collaborazione che ha prodotto un piccolo oggetto utilizzabile e ora un kit da rendere replicabile.

## Che cosa viene condiviso

Il contenitore v24 in 3MF, STL e STEP, il software pubblico, le istruzioni e questo racconto. Le licenze e lo stato delle prove sono indicati separatamente. Il progetto è indipendente e non è presentato come prodotto ufficiale o sponsorizzato da OpenAI, Bambu Lab o Waveshare.
