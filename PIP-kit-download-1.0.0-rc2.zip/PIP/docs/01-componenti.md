# 1. Componenti

Il contenitore v24 è progettato per questi componenti. Verifica i dettagli prima di acquistare: una scheda con un nome simile o una diversa spina USB può non entrare.

| Quantità | Componente | Specifica |
|---:|---|---|
| 1 | Scheda con display | Waveshare **ESP32-S3-LCD-1.69 V2**, senza touch, famiglia SKU 27932 |
| 1 | Cavo dati e alimentazione | **deleyCON MK6334**, USB-C maschio/USB-C maschio, una spina a 90°, ASIN **B0DGQJ1GV6**; riferimento confermato dal costruttore |
| 1 | Alimentatore USB | Uscita USB-C compatibile con il cavo; alimentazione USB standard della scheda |
| 4 | Viti scheda | M2 x 8 mm; da avvitare nei distanziali metallici della scheda |
| 3 | Viti guscio | M2,5 x 8 mm **a testa svasata** |
| 3 | Dadi | M2,5 standard, non autobloccanti maggiorati |
| circa 15 g | Filamento per il piatto | SUNLU PETG 1,75 mm Trasparente Bianco, più il margine per avvio e scarti |
| 1 set | Parti stampate | Corpo F24, retro R24 e tastino N24 |

Servono inoltre un piccolo cacciavite adatto alle viti, un computer per il primo caricamento e una rete Wi-Fi a **2,4 GHz**.

## Identifica la scheda

Acquista la versione **LCD senza touch**. La versione Touch-LCD-1.69 e le schede CYD non sono sostituti verificati. Il firmware è configurato per la revisione V2; per una scheda senza marcatura chiara confronta il retro con i riferimenti del produttore prima del montaggio.

- [Pagina prodotto Waveshare](https://www.waveshare.com/esp32-s3-lcd-1.69.htm)
- [Documentazione e revisioni](https://docs.waveshare.com/ESP32-S3-LCD-1.69)

I quattro distanziali metallici sono quelli già presenti sulla scheda di riferimento; non aggiungere rondelle o distanziali che ne cambino l'altezza. Se la tua scheda non ha la stessa disposizione, fermati e confrontala con le fotografie del progetto.

## Il cavo è parte del progetto

La spina angolare va sulla scheda, il filo esce lateralmente dal guscio. Non è previsto l'adattatore USB rigido delle vecchie prove e non esiste una presa USB femmina esterna nel case v24. L'estremità libera del cavo serve sia per l'alimentazione sia per il caricamento dal computer.

Misure riferite sul cavo di riferimento già inserito: circa **14 mm** di sporgenza del corpo oltre il bordo USB della scheda, **8 mm** dal piano frontale del vetro al retro della spina, filo **diametro 4 mm**, anello all'uscita del filo **diametro 8 mm**. Sono rilievi di progetto, senza una tolleranza certificata: non garantiscono da soli la compatibilità di un cavo alternativo.

La lunghezza del cavo dipende dalla distanza dall'alimentatore. Controlla che la variante acquistata mantenga lo stesso connettore, non soltanto il nome commerciale. ASIN e SKU sono identificativi del riferimento usato, non una verifica di stock o prezzo attuale.

## Budget

Il prezzo dipende da scheda, spedizione e materiale già disponibile. Questo kit non promette un costo totale fisso e non include un carrello aggiornato. Non sono necessari batteria, sensori separati, AMS o saldatore per la configurazione di riferimento.
