# 3. Installa il software

Questa guida si riferisce a **PIP Public 1.0.0-rc2** e alla Waveshare ESP32-S3-LCD-1.69 **V2 senza touch**. Non caricare il firmware su moduli diversi soltanto perché hanno uno schermo simile.

## Metodo principale: Arduino IDE

1. Installa [Arduino IDE 2](https://www.arduino.cc/en/software).
2. Apri Gestore schede, cerca **esp32 by Espressif Systems** e installa la versione **3.0.5**. Se il pacchetto non compare, segui la [guida ufficiale all'aggiunta dei pacchetti](https://support.arduino.cc/hc/en-us/articles/360016119519-Add-boards-to-Arduino-IDE) e usa l'indice stabile Espressif: `https://espressif.github.io/arduino-esp32/package_esp32_index.json`.
3. In Gestore librerie installa **GFX Library for Arduino 1.4.9** e **SensorLib 0.2.1**. Mantieni queste versioni per riprodurre la compilazione della candidata.
4. Estrai tutto il pacchetto. Apri `firmware/PIP_Public/PIP_Public.ino`, mantenendo nella stessa cartella tutti i file `.h` e `sketch.yaml`. Non aprire soltanto una copia isolata dell'INO.
5. Seleziona **Waveshare ESP32-S3-LCD-1.69**, PSRAM **Enabled**, USB Mode **Hardware CDC and JTAG**, USB CDC On Boot **Disabled**, Partition Scheme **Default**. Le etichette possono cambiare con la lingua dell'IDE; il profilo esatto è riportato sotto.
6. Collega la scheda con un cavo dati e seleziona la porta che compare. Chiudi altri monitor seriali o programmi che occupano la porta.
7. Premi **Verifica**. Se compila, premi **Carica**. Alla fine riavvia la scheda se non si riavvia automaticamente.
8. Al primo avvio attendi la schermata di configurazione PIP con nome rete e password. Prosegui con [Wi-Fi e uso](04-uso-e-problemi.md).

Se il caricamento non aggancia il dispositivo: tieni premuto **BOOT**, premi e rilascia **RESET**, poi rilascia BOOT. Riseleziona la porta che appare e riprova il caricamento. Non confondere BOOT/RESET con il tastino PWR del case. Se necessario lavora con la scheda fuori dal guscio.

Non è necessario scrivere la password Wi-Fi nel codice. Non occorre toccare librerie condivise, cambiare i driver del display o aggiungere ArduinoJson: il parser JSON è quello cJSON del core ESP32.

## Compilazione riproducibile con Arduino CLI

Installa le stesse versioni di core e librerie. Dalla cartella radice del pacchetto:

```sh
arduino-cli compile --fqbn 'esp32:esp32:waveshare_esp32_s3_lcd_169:PSRAM=enabled,USBMode=hwcdc,CDCOnBoot=default,PartitionScheme=default' --build-path build firmware/PIP_Public
```

Il file `sketch.yaml` conserva lo stesso FQBN, ma non installa automaticamente le dipendenze in Arduino IDE. Il codice originale e i componenti di terzi hanno condizioni separate: consulta [THIRD_PARTY.md](../THIRD_PARTY.md).

## Perché qui trovi i sorgenti

La prima consegna pubblica usa Arduino IDE come percorso di installazione: il download comprende il software completo da compilare e caricare, non soltanto una descrizione del progetto. I binari della candidata sono conservati separatamente per la prova del costruttore. Un installer che distribuisca anche core e SDK compilati sarà un'aggiunta successiva, con il relativo pacchetto delle dipendenze.

L'edizione pubblica usa il proprio spazio impostazioni `pip_public`: sul PIP personale non legge automaticamente Wi-Fi e chiavi salvate dalle edizioni Studio. Questo non costituisce un backup del vecchio programma. Installazione e funzioni di base sono state provate sulla scheda del costruttore; lo stato aggiornato delle verifiche, incluse quelle ancora aperte, è in [TESTING.md](../TESTING.md).

Riferimenti: [Waveshare/Arduino](https://docs.waveshare.com/ESP32-S3-LCD-1.69/Arduino), [Waveshare/caricamento](https://docs.waveshare.com/ESP32-S3-LCD-1.69/Firmware-Flashing), [esptool v4](https://docs.espressif.com/projects/esptool/en/release-v4/esp32/esptool/basic-commands.html).
