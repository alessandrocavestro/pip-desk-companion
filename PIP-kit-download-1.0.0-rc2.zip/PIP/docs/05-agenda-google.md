# 5. Agenda Google facoltativa

Puoi usare PIP senza agenda. Questa integrazione legge soltanto i calendari del tuo account ai quali hai accesso; non modifica eventi e non richiede la tua password Google dentro PIP.

## Crea il tuo collegamento

1. Apri [Google Apps Script](https://script.google.com/) con l'account che possiede i calendari.
2. Crea un progetto e copia il contenuto di `integrations/google-calendar/Code.gs` nel suo file di codice.
3. Nelle impostazioni del progetto abilita la visualizzazione di `appsscript.json`. Sostituiscine il contenuto con il manifesto incluso: fuso Europe/Rome e ambito calendario in sola lettura.
4. Il codice usa inizialmente il tuo calendario principale: `{id: 'primary', label: 'Personale'}`. Per aggiungerne altri, usa gli ID dalle impostazioni dei tuoi calendari e etichette brevi, fino a 31 byte UTF-8. Non inserire ID di altre persone senza avere accesso e motivo per usarli.
5. Esegui `inizializzaPip` dall'editor e autorizza la lettura. Se il tuo account o dominio impedisce Apps Script o la distribuzione richiesta, lascia l'agenda disattivata; non ridurre protezioni dell'account per aggirare il limite.
6. Distribuisci come **App web**, esecuzione come il tuo account e accesso **Chiunque**, se disponibile. Conserva l'URL finale che termina in `/exec`. In questa modalità il codice protegge gli appuntamenti con una chiave privata; chi possiede sia URL sia chiave può leggere gli eventi selezionati.
7. Apri Impostazioni progetto → Proprietà script e copia privatamente `PIP_DEVICE_TOKEN`, una chiave di 64 caratteri. Non inserirla nei sorgenti pubblici o in una richiesta di assistenza.
8. Apri le impostazioni locali di PIP, inserisci URL e chiave, attiva Agenda e salva. Non inserire la password Google.
9. Attendi un aggiornamento, poi raggiungi Agenda con i clic singoli e confronta sul display titolo e orario di un tuo appuntamento.

Aprendo `/exec` nel browser compare `use_post`: è previsto, non è l'elenco degli appuntamenti. Il dispositivo usa una richiesta POST con la chiave. Il servizio controlla la chiave prima di leggere cache e calendari.

## Personalizzazione e manutenzione

Il servizio restituisce fino a 16 impegni con orario e 4 eventi giornalieri, nei prossimi sette giorni. Due occorrenze dello stesso evento lette da più calendari vengono unite e indicate come “Più calendari”. Le etichette non devono contenere dati che non vuoi sul display.

Se modifichi il codice, aggiorna la distribuzione selezionando una nuova versione; salvare nell'editor da solo non aggiorna necessariamente l'app web. Se la chiave è stata esposta, esegui `rigeneraChiavePip` e sostituiscila nelle impostazioni del dispositivo.

Questa integrazione generalizza quella usata nel prototipo; la configurazione pubblica sul calendario principale deve completare una prova end-to-end prima del rilascio stabile. Le schermate di Google possono cambiare; riferimento: [guida ufficiale alle app web](https://developers.google.com/apps-script/guides/web).
