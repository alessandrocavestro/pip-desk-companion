# 4. Configurazione e uso

## Primo avvio

1. Alimenta PIP via USB. Al primo avvio compare la schermata Impostazioni con la rete `PIP-XXXX` e la sua password.
2. Sul telefono o computer collegati a quella rete. È normale che il sistema indichi che non ha accesso a internet: è la rete locale di configurazione.
3. Apri `http://192.168.4.1` nel browser. Se il telefono torna automaticamente ai dati mobili, mantieni manualmente la rete PIP selezionata.
4. Inserisci il nome della tua rete **2,4 GHz**, la sua password e la località per il meteo, ad esempio `Padova, Italia`.
5. Lascia Agenda disattivata per la prima prova, scegli luminosità e durata del timer e premi **Salva impostazioni**.
6. Esci con un clic PWR. Attendi la sincronizzazione dell'ora e il meteo; controlla che la città riconosciuta sia quella giusta.

L'access point si chiude dopo circa dieci minuti senza attività. Per riaprirlo tieni premuto PWR circa due secondi da una pagina diversa dal timer. Nome e password sono mostrati sul display; non pubblicarne fotografie leggibili.

## Comandi del tastino PWR

| Dove | Comando | Risultato |
|---|---|---|
| Uso normale | Un clic | Faccina → ora → meteo → timer → agenda, se configurata |
| Timer | Due clic | Avvia / pausa |
| Timer | Pressione lunga | Riporta alla durata impostata e resta fermo |
| Altre pagine | Pressione lunga | Apre le impostazioni |
| Impostazioni | Un clic | Chiude le impostazioni |
| Altre pagine | Due clic | Abilita / sospende l'alternanza automatica dell'agenda |
| Fine timer, “Fatto.” | Un clic | Torna alla faccina |

Con la selezione automatica attiva, una pagina scelta manualmente resta visibile circa 20 secondi; il timer scelto resta visibile finché lo lasci. Con la selezione automatica sospesa, la pagina manuale resta selezionata. In assenza di impegni vicini il riposo automatico è la faccina. Quando un impegno è vicino o in corso, e i dati sono recenti, PIP alterna agenda, ora e meteo. L'anticipo è regolabile, inizialmente 10 minuti, e l'intervallo è inizialmente 12 secondi.

La modalità serale, se attiva, riduce la luminosità nella schermata di riposo tra le 22:00 e le 07:00 e mostra la faccina assonnata con l'ora. Timer e impostazioni mantengono il proprio comportamento. PIP non è una sveglia sonora: il buzzer resta disattivato.

## Dati e servizi

- L'interfaccia usa il fuso italiano con ora legale automatica.
- Open-Meteo riceve il nome della località per la ricerca e poi le coordinate per il meteo; gli aggiornamenti riusciti sono distanziati di circa 15 minuti.
- L'ora viene sincronizzata tramite NTP. Faccina e timer non richiedono un abbonamento o un account AI.
- L'agenda, se attivata, legge il servizio Google configurato da te circa ogni due minuti. Non usa calendari del costruttore.
- Password e chiavi vengono salvate nella memoria del dispositivo; non sono incluse nel download. Non condividere dump della memoria, link privati o screenshot delle credenziali.

I dati meteo sono attribuiti a [Open-Meteo](https://open-meteo.com/). L'API gratuita è destinata all'uso non commerciale secondo le [condizioni del servizio](https://open-meteo.com/en/terms); un uso commerciale richiede di verificare un piano adeguato. La licenza del case non sostituisce le condizioni dei servizi esterni.

## Se qualcosa non funziona

| Sintomo | Primo controllo |
|---|---|
| Il computer non vede la scheda | Cavo dati, porta corretta, BOOT/RESET come nella guida software |
| Schermo nero o immagine errata | Modello V2 senza touch, PSRAM abilitata, librerie nelle versioni indicate |
| Nessun Wi-Fi | Rete 2,4 GHz e credenziali; riapri le impostazioni e risalva |
| Città sbagliata | Scrivi città e nazione, controlla il primo risultato riconosciuto |
| Ora errata | Il firmware è impostato per l'Italia; controlla sincronizzazione e ora del telefono |
| Meteo in attesa | Prima Wi-Fi e ora, poi la città; controlla disponibilità del servizio |
| Tasto duro o sempre premuto | Scollega e riapri il case; verifica orientamento N24 e interferenze senza serrare a forza |
| Movimento continuo da fermo | Appoggia su piano stabile, verifica versione e revisione V2; puoi disattivare temporaneamente la reazione nelle impostazioni |
| Agenda in attesa | Controlla URL `/exec`, chiave privata e distribuzione Google |

Per chiedere aiuto indica versione software, revisione scheda, stampante e filamento, sintomo e una foto del problema senza dati personali. Per gli errori di compilazione copia il testo dell'errore; non inviare password o token.
