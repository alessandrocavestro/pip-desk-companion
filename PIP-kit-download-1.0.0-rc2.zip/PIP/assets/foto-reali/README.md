# Fotografie del prototipo

Fotografie di Alessandro Cavestro, 18 novembre 2026, sotto la licenza della documentazione CC BY-NC-SA 4.0. Copie senza metadati privati, con pixel invariati rispetto agli originali. L'orientamento di visualizzazione e le informazioni colore sono conservati.

- 01: vista a tre quarti, faccina e cavo laterale.
- 02: vista frontale.
- 03: retro con le quattro viti che fissano la scheda ai suoi distanziali.
- 04: in mano, schermata orologio capovolta rispetto alla fotografia.

Documentano il guscio v24 realmente stampato e montato; non attestano la versione del firmware. La tavola montaggio-v24.png nella cartella superiore è invece un'illustrazione CAD.
