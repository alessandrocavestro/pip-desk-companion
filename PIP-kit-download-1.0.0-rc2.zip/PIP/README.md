# PIP - Dalla chat alla scrivania

Un piccolo compagno da scrivania stampato in 3D, progettato e sviluppato attraverso un percorso guidato da ChatGPT e costruito e provato da Alessandro Cavestro.

<img src="assets/foto-reali/01-PIP-tre-quarti-reale.jpg" alt="PIP reale: case PETG trasparente, faccina e cavo laterale" width="380" />

**Edizione pubblica 1.0.0-rc2.** Base Studio 1.5 con la correzione del movimento da fermo e impostazioni per i propri dati. Installazione sulla scheda V2, configurazione dal telefono, riavvio, ora/meteo, pulsante, avvio/pausa/reset del timer e presa/appoggio sono già stati provati. La scadenza del timer è verificata via USB; restano il suo riscontro visivo, l'Agenda pubblica e l'uso prolungato. È una candidata al rilascio: lo stato dettagliato è in [TESTING.md](TESTING.md).

## Cosa fa

- Faccina animata e reazione al movimento.
- Ora e data, con fuso italiano e ora legale automatica.
- Meteo via Wi-Fi per una località configurabile.
- Timer con avvio, pausa e ripristino della durata impostata.
- Modalità serale dalle 22:00 alle 07:00.
- Agenda Google facoltativa, in sola lettura, configurata sul proprio account.

L'AI è stata usata durante lo sviluppo. Il firmware esegue animazioni programmate: non contiene un modello AI e non richiede un account ChatGPT. Ora sincronizzata, meteo e agenda richiedono internet. L'alimentazione è USB; il computer può restare spento dopo la configurazione.

## Parti da qui

1. [Controlla e acquista i componenti](docs/01-componenti.md), soprattutto revisione della scheda e cavo.
2. [Installa il software](docs/03-software.md) e prova la scheda prima del montaggio.
3. [Stampa e assembla il contenitore](docs/02-stampa-e-montaggio.md).
4. [Configura Wi-Fi e impara i comandi](docs/04-uso-e-problemi.md).
5. Se ti serve, [collega la tua agenda Google](docs/05-agenda-google.md).
6. Leggi il [case study](docs/06-case-study.md).

Puoi seguire anche la [guida illustrata in PDF](docs/PIP-guida-illustrata.pdf): componenti, installazione, stampa, montaggio e comandi, con foto del prototipo reale.

## File da scaricare

| Cartella | Contenuto |
|---|---|
| `hardware/3MF` | Progetto Bambu Studio v24 completo, A1/ugello 0,4 mm/PETG |
| `hardware/STL` | Corpo, retro e tastino, già orientati per la stampa |
| `hardware/STEP` | Le tre parti modificabili, nella posizione di assemblaggio |
| `firmware/PIP_Public` | Tutti i sorgenti da aprire con Arduino IDE |
| `integrations/google-calendar` | Integrazione facoltativa per il proprio account |
| `docs` | Istruzioni e racconto del progetto |

Il 3MF usa un solo materiale e non richiede AMS. I file STEP sono posizionati per l'assemblaggio, non per la stampa. Non cambiare scala: le sedi sono progettate per la scheda specificata.

## Versione e limiti

La compatibilità copre la Waveshare ESP32-S3-LCD-1.69 **V2 senza touch**; altre revisioni non sono state validate. L'interfaccia è in italiano. Non sono incluse batteria o saldature aggiuntive.

Il case è stato stampato e montato da un costruttore con esito generale positivo. Questo non equivale a una validazione su tutte le stampanti, filamenti o unità della scheda. Le stime di tempo e peso derivano dallo slicer. Per lo stato esatto della candidata vedi [TESTING.md](TESTING.md).

## Licenze e crediti

Case, file STL/STEP/3MF e documentazione originale: **CC BY-NC-SA 4.0**. Download e modifiche consentiti per finalità non commerciali, con attribuzione e condivisione delle modifiche sotto la stessa licenza. Nessuna vendita autorizzata di stampe o file. [Dettagli](LICENSE-HARDWARE.md).

Codice originale: **PolyForm Noncommercial 1.0.0**, per uso e modifiche non commerciali. È codice sorgente disponibile con un vincolo d'uso, non una licenza open source. I componenti di terzi mantengono le rispettive licenze: vedi [THIRD_PARTY.md](THIRD_PARTY.md) e [LICENSE-SOFTWARE.md](LICENSE-SOFTWARE.md).

Progetto personale indipendente. ChatGPT è citato come strumento di sviluppo; nessuna affiliazione o approvazione di OpenAI, Bambu Lab o Waveshare è dichiarata.
