#pragma once
#include <math.h>
#include <stdint.h>

enum class PipPose:uint8_t {Calm,Sweet,Curious,Surprised,Happy,Sleepy};
inline const char* pipPoseName(PipPose p){
 switch(p){case PipPose::Sweet:return "sweet";case PipPose::Curious:return "curious";
 case PipPose::Surprised:return "surprised";case PipPose::Happy:return "happy";
 case PipPose::Sleepy:return "sleepy";default:return "calm";}
}

// Riconosce un nuovo gesto, poi si riarma solo dopo una pausa reale.
// Il riferimento segue la posizione in cui PIP viene appoggiato, non resta
// bloccato sul modulo e sull'inclinazione della prima accensione.
class PipMotion {
public:
 void sample(float x,float y,float z,uint32_t now){
  if(!isfinite(x)||!isfinite(y)||!isfinite(z))return;
  float norm=sqrtf(x*x+y*y+z*z);if(norm<.05f||norm>8)return;
  if(!ready){ready=true;started=activeAt=now;bx=gx=px=x;by=gy=py=y;bz=gz=pz=z;reference=norm;samples=1;return;}
  // Il primo campione può appartenere all'assestamento/cambio scala del sensore.
  // Media il modulo e la direzione separatamente, evitando una falsa accelerazione.
  if(!calibrated){
   reference+=(norm-reference)*.25f;bx+=(x-bx)*.25f;by+=(y-by)*.25f;bz+=(z-bz)*.25f;
   px=x;py=y;pz=z;activeAt=now;if(samples<255)++samples;
   if(now-started>=1200&&samples>=16)calibrated=true;
   return;
  }
  float jerk=sqrtf((x-px)*(x-px)+(y-py)*(y-py)+(z-pz)*(z-pz));px=x;py=y;pz=z;
  gx+=(x-gx)*.08f;gy+=(y-gy)*.08f;gz+=(z-gz)*.08f;
  float base=reference;jerk/=base;
  // Poco cambiamento istantaneo NON basta: una rotazione lenta accumulata
  // deve interrompere la quiete, altrimenti verrebbe calibrata come riposo.
  float drift=sqrtf((x-qx)*(x-qx)+(y-qy)*(y-qy)+(z-qz)*(z-qz))/base;
  if(!quietSet||jerk>.025f||drift>.04f){quietSet=true;quietAt=now;qx=x;qy=y;qz=z;}
  bool settled=now-quietAt>=1200;
  if(settled){
   reference=norm;bx=x;by=y;bz=z;base=norm;armed=true;
  }
  float direction=sqrtf(bx*bx+by*by+bz*bz);
  float cosine=direction>.01f?(x*bx+y*by+z*bz)/(norm*direction):1;
  tilted=cosine<.975f; // circa 13 gradi, rispetto alla posizione d'accensione.
  gaze=fmaxf(-10,fminf(10,(y-by)*15/base));
  float dynamic=fabsf(norm-base)/base;lastDynamic=dynamic;lastJerk=jerk;
  if(!settled&&(jerk>.055f||tilted))activeAt=now;
  if(!settled&&(armed||(jerk>1.1f&&reaction!=PipPose::Surprised))){
   bool strong=dynamic>.78f||jerk>1.1f;
   bool gentle=dynamic>.105f&&dynamic<.75f&&jerk>.025f;
   if(strong||gentle||tilted){
    reaction=strong?PipPose::Surprised:tilted?PipPose::Curious:PipPose::Sweet;
    reactionAt=activeAt=now;reactionSet=true;armed=false;++reactionCount;
   }
  }
 }
 PipPose pose(uint32_t now) const {
  if(!calibrated)return PipPose::Calm;
  if(reactionSet){uint32_t age=now-reactionAt;
   uint32_t hold=reaction==PipPose::Sweet?3000:950;
   if(age<hold)return reaction;
   if(age<hold+1400)return PipPose::Happy;
  }
  if(tilted)return PipPose::Curious;
  uint32_t quiet=now-activeAt;
  if(quiet>=90000)return PipPose::Sleepy;
  if(quiet>20000&&quiet%28000>24000)return PipPose::Happy;
  return PipPose::Calm;
 }
 float look() const{return gaze;}
 bool available() const{return ready;}
 float gravity() const{return reference;}
 float dynamic() const{return lastDynamic;}
 float jerk() const{return lastJerk;}
 uint32_t reactions()const{return reactionCount;}
 bool settled(uint32_t now)const{return calibrated&&quietSet&&now-quietAt>=1200;}
private:
 bool ready=false,calibrated=false,tilted=false,reactionSet=false,armed=true,quietSet=false;
 uint8_t samples=0;
 float reference=1,lastDynamic=0,lastJerk=0;
 float bx=0,by=0,bz=1,gx=0,gy=0,gz=1,px=0,py=0,pz=1,gaze=0;
 float qx=0,qy=0,qz=1;uint32_t quietAt=0;
 uint32_t started=0,activeAt=0,reactionAt=0,reactionCount=0;
 PipPose reaction=PipPose::Calm;
};

struct PipFace {
 float open=1,arch=0,asym=0,smile=.9f,mouthO=0,blush=0,tilt=0,y=0,look=0,sweet=0,brow=0;
};
inline PipFace pipFace(PipPose pose){
 switch(pose){
 case PipPose::Sweet:return {.04f,17,0,.65f,0,1,-5,-3,0,1,0};
 case PipPose::Curious:return {.94f,0,.22f,.35f,0,0,8,0,7,0,1};
 case PipPose::Surprised:return {1.2f,0,0,0,1,.18f,0,-4,0,0,0};
 case PipPose::Happy:return {.1f,15,0,1.2f,0,.65f,2,0,0,.25f,0};
 case PipPose::Sleepy:return {.1f,-2,0,.22f,0,0,-2,4,0,0,0};
 default:return {};
 }
}
