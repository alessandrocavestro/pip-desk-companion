#pragma once
#include "PipAgendaJson.h"

// Limite anche per risposte chunked: non leggere un documento illimitato in RAM.
class PipAgendaBody:public Stream {
public:
 String data;bool overflow=false;
 int available()override{return 0;}int read()override{return -1;}int peek()override{return -1;}void flush()override{}
 size_t write(uint8_t c)override{return write(&c,1);}
 size_t write(const uint8_t* buffer,size_t length)override{
  if(length>16384-data.length()){overflow=true;return 0;}
  if(!data.concat(reinterpret_cast<const char*>(buffer),length)){overflow=true;return 0;}return length;
 }
};

PipAgendaError fetchAgenda(const char* endpoint,const char* token,PipAgenda& result){
 if(!pipAgendaEndpoint(endpoint)||!pipAgendaToken(token))return PipAgendaError::Invalid;
 String url=endpoint;
 for(unsigned hop=0;hop<2;hop++){
  WiFiClientSecure client;client.setCACert(PIP_CA);client.setHandshakeTimeout(6);
  HTTPClient http;http.setConnectTimeout(6000);http.setTimeout(15000);
  http.setFollowRedirects(HTTPC_DISABLE_FOLLOW_REDIRECTS);
  const char* headers[]={"Location"};http.collectHeaders(headers,1);
  if(!http.begin(client,url))return PipAgendaError::Transport;
  int status;
  if(hop==0){
   http.addHeader("Content-Type","application/json");
   status=http.POST(String("{\"token\":\"")+token+"\"}");
  }else status=http.GET(); // Non inoltrare il segreto al dominio di redirect.
  if(hop==0&&(status==301||status==302||status==303)){
   String location=http.header("Location");http.end();
   if(!pipAgendaRedirect(location.c_str()))return PipAgendaError::Transport;
   url=location;continue;
  }
  PipAgendaError error=PipAgendaError::Transport;
  if(status==200&&http.getSize()<=16384){
   PipAgendaBody body;
   if(http.writeToStream(&body)>=0&&!body.overflow&&!body.data.isEmpty())error=pipParseAgenda(body.data.c_str(),time(nullptr),result);
  }
  http.end();return error;
 }
 return PipAgendaError::Transport;
}
