#pragma once
#include "PipAgenda.h"

inline void pipDrawAgenda(PipDisplay& screen,const PipAgenda& agenda,time_t now,bool connected,int forced=-1){
 if(!agenda.valid){
  const char* detail=!connected?"Wi-Fi non collegato":agenda.error==PipAgendaError::Unauthorized?"Chiave da verificare":
   agenda.failed?"Collegamento da verificare":"Aggiornamento...";
  screen.message("Agenda in attesa",detail);return;
 }
 const bool stale=pipAgendaStale(agenda,now,connected);
 int index=forced>=0?forced:pipAgendaSelection(agenda,now);
 if(index<0){screen.message(stale?"Agenda da aggiornare":"Nessun impegno",stale?"Ultimi dati non recenti":"Nei prossimi 7 giorni");return;}
 const auto& e=agenda.events[index];struct tm local,clock;localtime_r(&e.start,&local);localtime_r(&now,&clock);
 char hour[32],detail[64],footer[64];const char* heading=e.allDay?"GIORNATA INTERA":e.start<=now?"IN CORSO":"PROSSIMO IMPEGNO";
 if(e.allDay)strcpy(hour,"Tutto il giorno");else snprintf(hour,sizeof(hour),"%02d:%02d",local.tm_hour,local.tm_min);
 if(!e.allDay&&e.start<=now){struct tm end;localtime_r(&e.end,&end);snprintf(detail,sizeof(detail),"Fino alle %02d:%02d",end.tm_hour,end.tm_min);}
 else if(e.allDay&&e.start<=now)strcpy(detail,"Oggi");
 else if(!e.allDay&&e.start-now<86400){
  const long minutes=long((e.start-now+59)/60);
  if(minutes<60)snprintf(detail,sizeof(detail),"Tra %ld min",minutes);
  else if(minutes%60)snprintf(detail,sizeof(detail),"Tra %ld h %02ld min",minutes/60,minutes%60);
  else snprintf(detail,sizeof(detail),"Tra %ld ore",minutes/60);
 }else{
  const char* days[]={"Dom","Lun","Mar","Mer","Gio","Ven","Sab"};
  snprintf(detail,sizeof(detail),"%s %d/%02d",days[local.tm_wday],local.tm_mday,local.tm_mon+1);
 }
 if(stale){struct tm stamp;localtime_r(&agenda.generated,&stamp);snprintf(footer,sizeof(footer),"Ultimo dato %02d:%02d",stamp.tm_hour,stamp.tm_min);}
 else snprintf(footer,sizeof(footer),"%s",e.source);
 if(stale&&!e.allDay&&e.start>now)strcpy(detail,"Dati non aggiornati");
 long untilMinutes=(!e.allDay&&e.start>now&&!stale)?long((e.start-now+59)/60):-1;
 screen.appointment(heading,hour,e.title,detail,footer,e.allDay,stale,untilMinutes);
}
