#pragma once
#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include "PipFonts.h"
#include "PipMotion.h"

namespace PipColors {
constexpr uint16_t rgb(uint8_t r,uint8_t g,uint8_t b){return ((r>>3)<<11)|((g>>2)<<5)|(b>>3);}
constexpr uint16_t BG=rgb(22,25,25),PANEL=rgb(38,45,41),PILL=rgb(38,45,41),
 MINT=rgb(255,128,90),INK=rgb(241,240,230),DIM=rgb(162,170,164),
 TRACK=rgb(52,66,58),DONE=rgb(38,45,41),PINK=rgb(236,164,157);
inline uint16_t blend(uint16_t fg,uint16_t bg,uint8_t alpha){
 uint32_t r=(((fg>>11)&31)*alpha+((bg>>11)&31)*(15-alpha)+7)/15;
 uint32_t g=(((fg>>5)&63)*alpha+((bg>>5)&63)*(15-alpha)+7)/15;
 uint32_t b=((fg&31)*alpha+(bg&31)*(15-alpha)+7)/15;
 return (r<<11)|(g<<5)|b;
}
}

// Testo proporzionale antialias 4 bit; centratura sui limiti VISIBILI dei glifi.
class PipDisplay {
 Arduino_GFX* g;
 struct Bounds {int left=32767,top=32767,right=-32767,bottom=-32767;};
 static uint16_t code(const char*& p){
  uint8_t c=(uint8_t)*p++;if(c<128)return c;
  if((c&0xE0)==0xC0&&*p){uint8_t tail=(uint8_t)*p++;return ((c&31)<<6)|(tail&63);}
  while(((uint8_t)*p&0xC0)==0x80)++p;return '?';
 }
 static const PipGlyph* glyph(const PipFont& font,uint16_t c){
  for(uint16_t i=0;i<font.count;i++)if(font.glyphs[i].code==c)return &font.glyphs[i];
  if(c!='?')for(uint16_t i=0;i<font.count;i++)if(font.glyphs[i].code=='?')return &font.glyphs[i];
  return nullptr;
 }
 static Bounds bounds(const char* s,const PipFont& font){
  Bounds b;int pen=0;
  while(*s){const PipGlyph* k=glyph(font,code(s));if(!k)continue;
   if(k->w&&k->h){
    if(pen+k->xoff<b.left)b.left=pen+k->xoff;
    if(k->yoff<b.top)b.top=k->yoff;
    if(pen+k->xoff+k->w>b.right)b.right=pen+k->xoff+k->w;
    if(k->yoff+k->h>b.bottom)b.bottom=k->yoff+k->h;
   }pen+=k->advance;
  }return b;
 }
public:
 explicit PipDisplay(Arduino_GFX* graphics):g(graphics){}
 void clear(){g->fillScreen(PipColors::BG);}
 static int textWidth(const char* s,const PipFont& font){auto b=bounds(s,font);return b.right>=b.left?b.right-b.left:0;}
 void center(const char* s,int cy,const PipFont& preferred,uint16_t color=PipColors::INK,uint16_t background=PipColors::BG,int limit=238){
  const PipFont* font=&preferred;
  if(textWidth(s,*font)>limit)font=&PipFonts::F22;
  if(textWidth(s,*font)>limit)font=&PipFonts::F18;
  if(textWidth(s,*font)>limit)font=&PipFonts::F16;
  char shortText[144];
  if(textWidth(s,*font)>limit){
   snprintf(shortText,sizeof(shortText),"%s",s);size_t n=strlen(shortText);
   while(n&&textWidth(shortText,*font)>limit){
    do{--n;}while(n&&((uint8_t)shortText[n]&0xC0)==0x80);
    shortText[n]=0;
   }s=shortText;
  }
  Bounds b=bounds(s,*font);if(b.right<b.left)return;
  int x=(280-(b.right-b.left))/2-b.left,y=cy-(b.top+b.bottom)/2,pen=0;
  uint16_t palette[16];for(int i=0;i<16;i++)palette[i]=PipColors::blend(color,background,i);
  while(*s){const PipGlyph* k=glyph(*font,code(s));if(!k)continue;
   for(int yy=0;yy<k->h;yy++){
    for(int xx=0;xx<k->w;xx++){
     uint32_t at=yy*k->w+xx;uint8_t packed=font->data[k->offset+at/2];
     uint8_t alpha=(at&1)?packed&15:packed>>4;
     if(alpha)g->drawPixel(x+pen+k->xoff+xx,y+k->yoff+yy,palette[alpha]);
    }
   }
   pen+=k->advance;
  }
 }
 void left(const char* s,int x,int cy,const PipFont& preferred,uint16_t color=PipColors::INK,int limit=236){
  const PipFont* font=&preferred;
  if(textWidth(s,*font)>limit)font=(font==&PipFonts::F78||font==&PipFonts::F96)?&PipFonts::F61:&PipFonts::F22;
  if(textWidth(s,*font)>limit)font=&PipFonts::F22;
  if(textWidth(s,*font)>limit)font=&PipFonts::F18;
  if(textWidth(s,*font)>limit)font=&PipFonts::F16;
  char shortText[144];snprintf(shortText,sizeof(shortText),"%s",s);size_t n=strlen(shortText);
  while(n&&textWidth(shortText,*font)>limit){do{--n;}while(n&&((uint8_t)shortText[n]&0xc0)==0x80);shortText[n]=0;}
  s=shortText;Bounds b=bounds(s,*font);if(b.right<b.left)return;
  int pen=0,y=cy-(b.top+b.bottom)/2;uint16_t palette[16];
  for(int i=0;i<16;i++)palette[i]=PipColors::blend(color,PipColors::BG,i);
  while(*s){const PipGlyph* k=glyph(*font,code(s));if(!k)continue;
   for(int yy=0;yy<k->h;yy++)for(int xx=0;xx<k->w;xx++){
    uint32_t at=yy*k->w+xx;uint8_t packed=font->data[k->offset+at/2],alpha=(at&1)?packed&15:packed>>4;
    if(alpha)g->drawPixel(x-b.left+pen+k->xoff+xx,y+k->yoff+yy,palette[alpha]);
   }pen+=k->advance;
  }
 }
 void appointment(const char* heading,const char* hour,const char* title,const char* detail,const char* footer,bool allDay=false,bool stale=false,long untilMinutes=-1){
  using namespace PipColors;clear();left(heading,22,29,PipFonts::F16,DIM);
  if(!stale&&untilMinutes>=0&&untilMinutes<60){char amount[12];snprintf(amount,sizeof(amount),"%ld",untilMinutes);
   left(amount,22,99,PipFonts::F96,MINT,145);left("min",175,124,PipFonts::F22,DIM,75);
  }else left(hour,22,91,allDay?PipFonts::F26:PipFonts::F78);
  char lines[2][128]={};const char* cursor=title;
  for(unsigned line=0;line<2;line++){
   while(*cursor==' ')++cursor;
   const char* p=cursor;size_t fit=0;
   while(*p){const char* before=p;code(p);size_t n=p-cursor;if(n>=120)break;
    memcpy(lines[line],cursor,n);lines[line][n]=0;
    if(textWidth(lines[line],PipFonts::F22)>232){p=before;break;}fit=n;
   }
   if(!cursor[fit]){memcpy(lines[line],cursor,fit);lines[line][fit]=0;break;}
   if(line==0){
    size_t word=fit;while(word&&cursor[word]!=' ')--word;if(word)fit=word;
    memcpy(lines[line],cursor,fit);lines[line][fit]=0;cursor+=fit;
   }else{
    while(true){
     memcpy(lines[line],cursor,fit);strcpy(lines[line]+fit,"...");
     if(textWidth(lines[line],PipFonts::F22)<=232||!fit)break;
     do{--fit;}while(fit&&((uint8_t)cursor[fit]&0xc0)==0x80);
    }
   }
  }
  left(lines[0],22,lines[1][0]?154:165,PipFonts::F22);
  if(lines[1][0])left(lines[1],22,181,PipFonts::F22);
  char ending[100];
  if(untilMinutes>=0&&!stale)snprintf(ending,sizeof(ending),"%s · %s",hour,footer);
  else snprintf(ending,sizeof(ending),"%s",detail);
  left(ending,22,209,PipFonts::F18,stale?PINK:DIM);
  if(untilMinutes<0||stale)left(footer,22,226,PipFonts::F16,stale?PINK:DIM);
 }
 void clock(const char* hour,const char* day,const char* date){
  using namespace PipColors;clear();left(day,22,30,PipFonts::F16,DIM);
  left(hour,22,105,PipFonts::F78);g->fillRoundRect(22,148,36,3,1,MINT);
  left(date,22,195,PipFonts::F26,DIM);
 }
 void weather(const char* place,int temperature,const char* sky,int humidity,int wind,const char* stale){
  using namespace PipColors;clear();left(place,22,29,PipFonts::F18,DIM);
  char value[24];snprintf(value,sizeof(value),"%d°",temperature);
  left(value,22,107,PipFonts::F96);
  left(sky,22,181,PipFonts::F26);
  if(stale&&*stale)left(stale,22,217,PipFonts::F16,MINT);
 }
 void message(const char* title,const char* detail){
  clear();left(title,22,90,PipFonts::F26,PipColors::INK);
  if(detail&&*detail)left(detail,22,139,PipFonts::F18,PipColors::DIM);
 }
 void settings(const char* network,const char* password,bool connected){
  using namespace PipColors;clear();center("CONFIGURA PIP",27,PipFonts::F18,MINT);
  g->fillRoundRect(24,52,232,55,20,PILL);center(network,80,PipFonts::F26,INK,PILL,216);
  g->fillRoundRect(24,117,232,57,20,PILL);center("Password",130,PipFonts::F16,MINT,PILL);
  center(password,155,PipFonts::F22,INK,PILL,216);
  center("192.168.4.1",197,PipFonts::F22,MINT);
  center(connected?"Wi-Fi collegato":"Wi-Fi non collegato",226,PipFonts::F16,DIM);
 }
 void timer(uint32_t remaining,uint32_t total,bool running,bool done,const char* ending=""){
  using namespace PipColors;clear();
  if(done){face(pipFace(PipPose::Happy),false,.67f,84);center("Fatto.",183,PipFonts::F45);return;}
  left(running?"FOCUS":remaining==total?"PRONTO":"IN PAUSA",22,29,PipFonts::F16,running?MINT:DIM);
  float fraction=total?fminf(1.f,(float)remaining/total):0;
  g->fillRoundRect(22,180,236,5,2,TRACK);
  if(fraction>0)g->fillRoundRect(22,180,lroundf(236*fraction),5,2,MINT);
  uint32_t seconds=(remaining+999)/1000;char line[24];
  snprintf(line,sizeof(line),"%02lu:%02lu",(unsigned long)(seconds/60),(unsigned long)(seconds%60));
  left(line,22,106,seconds/60>=100?PipFonts::F61:PipFonts::F78);
  char duration[40];snprintf(duration,sizeof(duration),"su %lu minuti",(unsigned long)(total/60000));
  left(duration,22,151,PipFonts::F18,DIM);
  if(ending&&*ending)left(ending,22,217,PipFonts::F18,DIM);
 }
private:
 float angle=0,offsetY=0,faceScale=1,faceCenter=120;
 void point(float x,float y,int& xx,int& yy){
  float dx=x-140,dy=y-120;xx=lroundf(140+faceScale*(dx*cosf(angle)-dy*sinf(angle)));
  yy=lroundf(faceCenter+faceScale*(offsetY+dx*sinf(angle)+dy*cosf(angle)));
 }
 void dot(float x,float y,int radius,uint16_t color){int xx,yy;point(x,y,xx,yy);g->fillCircle(xx,yy,fmaxf(1,lroundf(radius*faceScale)),color);}
 void capsule(float cx,float cy,float w,float h,float r,uint16_t color){
  int midX,midY;point(cx,cy,midX,midY);int prevX=0,prevY=0,firstX=0,firstY=0;
  r=fminf(r,fminf(w,h)/2);
  for(int corner=0;corner<4;corner++){
   for(int step=0;step<=6;step++){
    float a=(corner*90+step*15)*.01745329252f;
    float ccx=cx+((corner==0||corner==3)?1:-1)*(w/2-r);
    float ccy=cy+((corner<2)?1:-1)*(h/2-r);
    int x,y;point(ccx+r*cosf(a),ccy+r*sinf(a),x,y);
    if(corner||step)g->fillTriangle(midX,midY,prevX,prevY,x,y,color);else{firstX=x;firstY=y;}
    prevX=x;prevY=y;
   }
  }
  g->fillTriangle(midX,midY,prevX,prevY,firstX,firstY,color);
 }
 void curve(float x0,float y0,float x1,float y1,float x2,float y2,int radius,uint16_t color){
  for(int i=0;i<=32;i++){float t=i/32.f,u=1-t;dot(u*u*x0+2*u*t*x1+t*t*x2,u*u*y0+2*u*t*y1+t*t*y2,radius,color);}
 }
public:
 void face(const PipFace& p,bool blink=false,float scale=1,float cy=120){
  using namespace PipColors;clear();faceScale=scale;faceCenter=cy;
  g->fillRoundRect(lroundf(140-105*scale),lroundf(cy-85*scale),lroundf(210*scale),lroundf(170*scale),lroundf(59*scale),PANEL);
  angle=p.tilt*.01745329252f;offsetY=p.y;
  for(int side=-1;side<=1;side+=2){
   float open=blink?.025f:fmaxf(.025f,fminf(1.35f,p.open*(1+side*p.asym)));
   float x=140+side*51+p.look,y=98-side*p.asym*8,h=65*open;
   float alpha=fminf(1.f,fmaxf(0.f,(open-.1f)/.24f));
   if(alpha>0)capsule(x,y,44,h,fminf(22,h/2),blend(MINT,PANEL,lroundf(alpha*15)));
   if(alpha<1)curve(x-21,y+5,x,y+5-(blink?0:p.arch)*2,x+21,y+5,3,blend(MINT,PANEL,lroundf((1-alpha)*15)));
   if(p.brow>.02f&&side==-1)curve(x-18,y-47,x,y-57,x+18,y-49,2,blend(MINT,PANEL,lroundf(p.brow*15)));
  }
  if(p.blush>.02f){uint16_t pink=blend(PINK,PANEL,lroundf(fminf(1,p.blush)*11));
   for(int side=-1;side<=1;side+=2){int xx,yy;point(140+78*side,139,xx,yy);g->fillEllipse(xx,yy,lroundf(13*scale),lroundf(6*scale),pink);}
  }
  if(p.mouthO>.02f){uint16_t color=blend(MINT,PANEL,lroundf(p.mouthO*15));
   for(int i=0;i<48;i++){float a=i*.130899694f;dot(140+9*cosf(a),160+(12*p.mouthO+2)*sinf(a),2,color);}
  }
  if(p.mouthO<.98f){float w=20+3*p.smile;uint16_t color=blend(MINT,PANEL,lroundf((1-p.mouthO)*15));
   if(p.sweet>.2f){curve(140-w,158,140-w/2,158+16*p.smile,140,158+3*p.smile,2,color);
    curve(140,158+3*p.smile,140+w/2,158+16*p.smile,140+w,158,2,color);
   }else curve(140-w,158,140,158+25*p.smile,140+w,158,2,color);
  }
 }
 void evening(const char* hour){face(pipFace(PipPose::Sleepy),false,.78f,102);center(hour,213,PipFonts::F49,PipColors::DIM);}
};
