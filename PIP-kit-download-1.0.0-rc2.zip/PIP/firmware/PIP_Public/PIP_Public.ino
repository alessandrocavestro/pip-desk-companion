// PIP Public 1.0.0-rc2 - based on the pre-running Studio 1.5 source.
// Public configuration uses user-owned credentials and optional calendars.
// Waveshare ESP32-S3-LCD-1.69 V2, senza touch/audio.
// Core esp32 3.0.5, Arduino_GFX 1.4.9, SensorLib 0.2.1; cJSON del core ESP-IDF.
#include <Arduino.h>
#include <Wire.h>
#include <Arduino_GFX_Library.h>
#include <SensorQMI8658.hpp>
#include <SensorPCF85063.hpp>
#include <WiFi.h>
#include <WebServer.h>
#include <DNSServer.h>
#include <HTTPClient.h>
#include <WiFiClientSecure.h>
#include <Preferences.h>
#include <HWCDC.h>
#include <cJSON.h>
#include <time.h>
#include <sys/time.h>
#include "PipLogic.h"
#include "PipTrust.h"
#include "PipDisplay.h"
#include "PipAgenda.h"
#include "PipAgendaView.h"
#include "PipExperience.h"

constexpr int PWR=40,ENABLE=41,BUZZER=42,BACKLIGHT=15;
constexpr const char* TZ_ROME="CET-1CEST,M3.5.0,M10.5.0/3";
Arduino_DataBus* bus=new Arduino_ESP32SPI(4,5,6,7);
Arduino_GFX* panel=new Arduino_ST7789(bus,8,1,true,240,280,0,20,0,0);
Arduino_GFX* gfx=new Arduino_Canvas(280,240,panel);
PipDisplay screen(gfx);PipMotion motionTracker;
SensorQMI8658 imu;SensorPCF85063 rtc;IMUdata acc={};
Preferences prefs;PipInput input;PipTimer timer;
HWCDC USBSerial;
WebServer server(IPAddress(192,168,4,1),80);DNSServer dns;
bool displayOK=false,imuOK=false,rtcOK=false,ap=false,ntpStarted=false,dirty=true;
bool motion=true,automatic=true,flip=false;uint8_t brightness=65,intervalSec=12;
uint16_t timerMinutes=25;uint8_t page=0;
uint32_t pageAt=0,lastPaint=0,lastSample=0,apActivity=0,lastRetry=0,lastRtc=0;
String ssid,password,city="",apName,apPassword,csrf;
PipPose facePose=PipPose::Calm;
PipFace faceFrom={},faceCurrent={};uint32_t faceAt=0;
uint32_t timerRestarts=0,paintMs=0,paintCount=0;

String agendaUrl,agendaToken;
bool agendaEnabled=false,eveningEnabled=true;uint16_t leadMinutes=10;
PipExperience experience;bool nightMode=false,wild=false,wildEver=false;
uint32_t wildAt=0,lastWildAt=0,lastReactions=0;
PipAgenda agenda;
bool agendaConfigured(){return agendaEnabled&&pipAgendaEndpoint(agendaUrl.c_str())&&pipAgendaToken(agendaToken.c_str());}
uint8_t pageCount(){return agendaConfigured()?5:4;}
struct NetConfig {char city[96],agendaUrl[256],agendaToken[65];bool agendaOn;uint32_t generation;};
struct Weather {bool valid;bool failed;bool locationNotFound;float temperature,wind;int humidity,code;
 time_t measured;char place[112];uint32_t generation;};
Weather fetchWeather(const NetConfig& cfg,bool& resolved,double& lat,double& lon,char* place);
QueueHandle_t configQueue=nullptr,resultQueue=nullptr,agendaQueue=nullptr;
Weather weather={};uint32_t configGeneration=1;
bool networkStarted=false;
const char* volatile netStage="start";
volatile int netHTTP=0,netTLS=0;
volatile uint32_t netRequests=0,netBytes=0;

bool validClock(){return time(nullptr)>1704067200;}
String htmlEscape(String s){s.replace("&","&amp;");s.replace("<","&lt;");s.replace(">","&gt;");s.replace("\"","&quot;");s.replace("'","&#39;");return s;}
String urlEncode(const String& s){
 String out;const char* hex="0123456789ABCDEF";
 for(size_t i=0;i<s.length();i++){uint8_t c=s[i];
  if(isalnum(c)||c=='-'||c=='_'||c=='.'||c=='~')out+=(char)c;
  else{out+='%';out+=hex[c>>4];out+=hex[c&15];}}
 return out;
}
String lcdLabel(const char* s,size_t max=25){
 String out;
 for(size_t i=0;s[i]&&out.length()<max;i++){
  uint8_t c=s[i];if(c>=32&&c<127)out+=(char)c;
  else if(c==0xC3&&s[i+1]){uint8_t n=s[++i];
   if(n==0xA0||n==0xA1||n==0xA2||n==0xA4)out+='a';
   else if(n==0xA8||n==0xA9||n==0xAA||n==0xAB)out+='e';
   else if(n==0xAC||n==0xAD||n==0xAE||n==0xAF)out+='i';
   else if(n==0xB2||n==0xB3||n==0xB4||n==0xB6)out+='o';
   else if(n==0xB9||n==0xBA||n==0xBB||n==0xBC)out+='u';
   else out+='?';
  }else if((c&0xC0)!=0x80)out+='?';
 }
 return out;
}

bool getJSON(const String& url,String& body,const char* endpoint){
 WiFiClientSecure client;client.setCACert(PIP_CA);client.setHandshakeTimeout(6);
 HTTPClient http;http.setConnectTimeout(5000);http.setTimeout(5000);
 netRequests++;netHTTP=0;netTLS=0;netBytes=0;
 if(!http.begin(client,url)){netHTTP=-999;return false;}
 int code=http.GET();bool ok=code==200&&http.getSize()<=16384;
 if(ok){body=http.getString();ok=body.length()>0&&body.length()<=16384;}
 char error[120];netHTTP=code;netTLS=code<0?client.lastError(error,sizeof(error)):0;netBytes=body.length();
 USBSerial.printf("PIP HTTP endpoint=%s code=%d tls=%d bytes=%lu ok=%d\n",endpoint,code,(int)netTLS,(unsigned long)netBytes,ok);
 http.end();return ok;
}
bool number(cJSON* parent,const char* key,double& value){
 cJSON* item=cJSON_GetObjectItemCaseSensitive(parent,key);
 if(!cJSON_IsNumber(item)||!isfinite(item->valuedouble))return false;
 value=item->valuedouble;return true;
}
#include "PipAgendaNetwork.h"

// Rete su un task separato: il display e i pulsanti non attendono le richieste HTTP.
Weather fetchWeather(const NetConfig& cfg,bool& resolved,double& lat,double& lon,char* place){
  Weather result={};result.generation=cfg.generation;String body;
  netStage="geocoding";
  if(!resolved&&getJSON("https://geocoding-api.open-meteo.com/v1/search?count=1&language=it&name="+urlEncode(cfg.city),body,"geocoding")){
   cJSON* doc=cJSON_Parse(body.c_str());
   cJSON* entry=cJSON_GetArrayItem(cJSON_GetObjectItemCaseSensitive(doc,"results"),0);
   result.locationNotFound=cJSON_IsObject(doc)&&!cJSON_GetObjectItemCaseSensitive(doc,"error")&&!entry;
   if(entry&&number(entry,"latitude",lat)&&number(entry,"longitude",lon)&&lat>=-90&&lat<=90&&lon>=-180&&lon<=180){
    auto str=[&](const char* key)->const char*{cJSON* n=cJSON_GetObjectItemCaseSensitive(entry,key);return cJSON_IsString(n)?n->valuestring:"";};
    snprintf(place,112,"%s, %s (%s)",str("name"),str("admin1"),str("country_code"));resolved=true;
   }
   cJSON_Delete(doc);
  }
  if(resolved){
   netStage="weather";
   String url="https://api.open-meteo.com/v1/forecast?latitude="+String(lat,5)+"&longitude="+String(lon,5)+
    "&current=temperature_2m,relative_humidity_2m,weather_code,wind_speed_10m&timeformat=unixtime&timezone=UTC";
   if(getJSON(url,body,"weather")){
    cJSON* doc=cJSON_Parse(body.c_str());cJSON* current=cJSON_GetObjectItemCaseSensitive(doc,"current");
    double temp,wind,humidity,code,stamp;
    if(number(current,"temperature_2m",temp)&&number(current,"wind_speed_10m",wind)&&
       number(current,"relative_humidity_2m",humidity)&&number(current,"weather_code",code)&&number(current,"time",stamp)&&
       temp>=-100&&temp<=65&&humidity>=0&&humidity<=100&&wind>=0&&wind<=500&&code>=0&&code<=99&&stamp>1704067200){
     result.valid=true;result.temperature=temp;result.wind=wind;result.humidity=humidity;result.code=code;result.measured=(time_t)stamp;
    }
    cJSON_Delete(doc);
   }
  }
  result.failed=!result.valid;strlcpy(result.place,place,sizeof(result.place));
  netStage=result.valid?"ready":resolved?"weather_failed":"geocoding_failed";
 return result;
}
void networkTask(void*){
 NetConfig cfg={};uint32_t nextWeather=0,nextAgenda=0;bool resolved=false;double lat=0,lon=0;
 char place[112]={};
 for(;;){
  NetConfig incoming;
  if(xQueueReceive(configQueue,&incoming,0)==pdTRUE){cfg=incoming;resolved=false;nextWeather=nextAgenda=0;}
  if(WiFi.status()!=WL_CONNECTED||!validClock()){
   netStage=WiFi.status()!=WL_CONNECTED?"wait_wifi":"wait_clock";
   vTaskDelay(pdMS_TO_TICKS(200));continue;
  }
  uint32_t now=millis();
  if(cfg.city[0]&&(!nextWeather||(int32_t)(now-nextWeather)>=0)){
   Weather result=fetchWeather(cfg,resolved,lat,lon,place);
   xQueueOverwrite(resultQueue,&result);nextWeather=millis()+(result.valid?900000UL:60000UL);
  }
  now=millis();
  if(cfg.agendaOn&&(!nextAgenda||(int32_t)(now-nextAgenda)>=0)){
   netStage="agenda";PipAgenda result;
   result.error=fetchAgenda(cfg.agendaUrl,cfg.agendaToken,result);
   result.failed=result.error!=PipAgendaError::None;result.generation=cfg.generation;
   xQueueOverwrite(agendaQueue,&result);nextAgenda=millis()+(result.valid?120000UL:60000UL);
   netStage=result.valid?"ready":"agenda_failed";
  }
  vTaskDelay(pdMS_TO_TICKS(200));
 }
}
void queueLocation(){
 NetConfig cfg={};strlcpy(cfg.city,city.c_str(),sizeof(cfg.city));cfg.generation=configGeneration;
 cfg.agendaOn=agendaConfigured();strlcpy(cfg.agendaUrl,agendaUrl.c_str(),sizeof(cfg.agendaUrl));strlcpy(cfg.agendaToken,agendaToken.c_str(),sizeof(cfg.agendaToken));
 if(configQueue)xQueueOverwrite(configQueue,&cfg);
}

void reportStatus(){
 USBSerial.printf("PIP STATUS v=1.0.0-rc2 ui=Public uptime=%lu wifi=%d clock=%d city_set=%d city_bytes=%u worker=%d stage=%s http=%d tls=%d bytes=%lu requests=%lu weather=%d failed=%d heap=%lu psram=%lu page=%u pose=%s timer_ms=%lu running=%d done=%d restarts=%lu paint_ms=%lu paints=%lu acc=%.3f/%.3f/%.3f\n",
  (unsigned long)millis(),(int)WiFi.status(),validClock(),!city.isEmpty(),(unsigned)city.length(),networkStarted,netStage,(int)netHTTP,(int)netTLS,
  (unsigned long)netBytes,(unsigned long)netRequests,weather.valid,weather.failed,(unsigned long)ESP.getFreeHeap(),(unsigned long)ESP.getFreePsram(),
  page,pipPoseName(facePose),(unsigned long)timer.remaining,timer.running,timer.done,(unsigned long)timerRestarts,(unsigned long)paintMs,(unsigned long)paintCount,acc.x,acc.y,acc.z);
 USBSerial.printf("PIP AGENDA configured=%d valid=%d failed=%d error=%u count=%u\n",agendaConfigured(),agenda.valid,agenda.failed,(unsigned)agenda.error,agenda.count);
 USBSerial.printf("PIP MOTION gravity=%.3f dynamic=%.3f jerk=%.3f\n",motionTracker.gravity(),motionTracker.dynamic(),motionTracker.jerk());
}

void restartTimer(uint16_t minutes,uint32_t now){
 timer.restart(minutes,now);timerRestarts++;page=3;pageAt=now;dirty=true;
 USBSerial.printf("PIP TIMER restart duration_s=%u count=%lu\n",minutes*60,(unsigned long)timerRestarts);
}

void resetFocus(uint16_t minutes,uint32_t now){
 pipResetFocus(timer,minutes);page=3;pageAt=now;dirty=true;
 USBSerial.printf("PIP TIMER reset_stopped duration_s=%u\n",minutes*60);
}
bool isNight(){
 if(!eveningEnabled||!validClock())return false;
 time_t sec=time(nullptr);struct tm local;localtime_r(&sec,&local);
 return local.tm_hour>=22||local.tm_hour<7;
}

void savePreferences(){
 prefs.putString("ssid",ssid);prefs.putString("pass",password);prefs.putString("city",city);
 prefs.putString("agenda_url",agendaUrl);prefs.putString("agenda_key",agendaToken);prefs.putBool("agenda_on",agendaEnabled);prefs.putUShort("lead_min",leadMinutes);prefs.putBool("night_on",eveningEnabled);
 prefs.putBool("studio_auto",automatic);prefs.putBool("motion",motion);prefs.putBool("flip",flip);
 prefs.putUChar("light",brightness);prefs.putUChar("interval",intervalSec);prefs.putUShort("minutes",timerMinutes);
}
void restoreRTC(){
 if(!rtcOK)return;RTC_DateTime d=rtc.getDateTime();
 if(!d.available||d.year<2024||d.year>2099||d.month<1||d.month>12||d.day<1||d.day>31||d.hour>23||d.minute>59||d.second>59)return;
 struct tm t={};t.tm_year=d.year-1900;t.tm_mon=d.month-1;t.tm_mday=d.day;t.tm_hour=d.hour;t.tm_min=d.minute;t.tm_sec=d.second;t.tm_isdst=-1;
 time_t e=mktime(&t);if(e>1704067200){struct timeval tv={e,0};settimeofday(&tv,nullptr);}
}
void syncRTC(){
 if(!rtcOK||!validClock())return;time_t now=time(nullptr);struct tm t;localtime_r(&now,&t);
 rtc.setDateTime(t.tm_year+1900,t.tm_mon+1,t.tm_mday,t.tm_hour,t.tm_min,t.tm_sec);
}
String pageHTML(){
 String h=F("<!doctype html><html lang='it'><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>PIP</title><style>body{font:17px system-ui;max-width:520px;margin:auto;padding:24px;background:#f4f1e9;color:#263b2b}h1{margin-bottom:4px}label{display:block;margin-top:18px}input,button{font:inherit;padding:11px;box-sizing:border-box;max-width:100%}input:not([type=checkbox]){width:100%}button{background:#486443;color:white;border:0;border-radius:10px;margin-top:20px}small{display:block;color:#4c5b4c;margin-top:8px}.check{display:flex;gap:10px;align-items:center}</style><h1>Ciao, sono PIP</h1><p>Impostazioni</p><form method='post' action='/save'>");
 h+="<input type='hidden' name='token' value='"+csrf+"'><input type='hidden' name='epoch' id='epoch'>";
 h+="<label>Nome della rete Wi-Fi<input name='ssid' maxlength='32' value='"+htmlEscape(ssid)+"' autocomplete='off'></label>";
 h+=F("<label>Password Wi-Fi<input name='password' type='password' maxlength='63' autocomplete='new-password'></label><small>Lascia vuoto per conservare la password già salvata.</small>");
 h+="<label>Città per il meteo<input name='city' maxlength='80' placeholder='Per esempio: Padova, Italia' value='"+htmlEscape(city)+"'></label>";
 h+=F("<small>Scrivi città e nazione, per esempio Padova, Italia. PIP mostra la prima località riconosciuta: controlla il nome nella schermata meteo. Puoi specificare anche una regione; le province non sono riconosciute come regioni.</small>");
 h+="<hr><h2>Agenda</h2><label class='check'><input type='checkbox' name='agenda_on' "+String(agendaEnabled?"checked":"")+">Mostra la mia agenda Google</label>";
 h+="<label>Collegamento Google<input name='agenda_url' type='url' maxlength='255' placeholder='https://script.google.com/macros/s/…/exec' value='"+htmlEscape(agendaUrl)+"'></label>";
 h+=F("<label>Chiave di PIP<input name='agenda_key' type='password' maxlength='64' autocomplete='new-password'></label><small>Lascia vuoto per conservare la chiave salvata. Non inserire la password Google.</small>");
 h+="<label>Minuti prima dell’appuntamento<input name='lead' type='number' min='1' max='60' value='"+String(leadMinutes)+"'></label>";
 h+=F("<small>Solo lettura. Da quando l’impegno si avvicina fino alla fine alterna agenda, ora e meteo. Richiede dati recenti; aggiornamento ogni 2 minuti circa. Il timer e le impostazioni hanno precedenza.</small><hr>");
 h+="<label>Luminosità (%)<input name='light' type='number' min='10' max='100' value='"+String(brightness)+"'></label>";
 h+="<label>Durata timer (minuti)<input name='minutes' type='number' min='1' max='180' value='"+String(timerMinutes)+"'></label>";
 h+="<label>Secondi per schermata<input name='interval' type='number' min='5' max='60' value='"+String(intervalSec)+"'></label>";
 h+="<label class='check'><input type='checkbox' name='auto' "+String(automatic?"checked":"")+">Agenda automatica; a riposo resta la faccina</label>";
 h+="<label class='check'><input type='checkbox' name='motion' "+String(motion?"checked":"")+">Faccina sensibile al movimento</label>";
 h+="<label class='check'><input type='checkbox' name='night' "+String(eveningEnabled?"checked":"")+">Modalità serale 22:00–07:00</label>";
 h+="<label class='check'><input type='checkbox' name='flip' "+String(flip?"checked":"")+">Capovolgi l'immagine di 180°</label>";
 h+=F("<button>Salva impostazioni</button></form><hr><form method='post' action='/timer'>");
 h+="<input type='hidden' name='token' value='"+csrf+"'><button name='action' value='toggle'>Avvia / pausa timer</button> <button name='action' value='restart'>Ricomincia e avvia</button> <button name='action' value='reset'>Azzera timer</button></form>";
 h+=F("<small>Orario: Italia, con cambio automatico ora legale. La configurazione aggiorna anche l'ora dal telefono.</small><small>Meteo: <a href='https://open-meteo.com/'>Open-Meteo</a>, dati aggiornati circa ogni 15 minuti. La località scelta viene inviata a Open-Meteo; password e rete Wi-Fi restano su PIP.</small><script>document.getElementById('epoch').value=Math.floor(Date.now()/1000)</script></html>");
 return h;
}
bool authorised(){
 apActivity=millis();if(!ap||server.arg("token")!=csrf){server.send(403,"text/plain","Riapri le impostazioni di PIP.");return false;}return true;
}
void setupRoutes(){
 server.on("/",HTTP_GET,[]{apActivity=millis();server.sendHeader("Cache-Control","no-store");server.send(200,"text/html; charset=utf-8",pageHTML());});
 server.on("/save",HTTP_POST,[]{
  if(!authorised())return;
  String nextSSID=server.arg("ssid"),nextPass=server.arg("password"),nextCity=server.arg("city");nextCity.trim();
  if(nextSSID.length()>32||nextCity.length()>80||(!nextPass.isEmpty()&&(nextPass.length()<8||nextPass.length()>63))){
   server.send(400,"text/plain; charset=utf-8","Controlla nome rete, password (8-63 caratteri) e città.");return;
  }
  String nextAgendaUrl=server.arg("agenda_url"),nextAgendaKey=server.arg("agenda_key");nextAgendaUrl.trim();nextAgendaKey.trim();
  if(nextAgendaKey.isEmpty())nextAgendaKey=agendaToken;
  const bool nextAgendaEnabled=server.hasArg("agenda_on");
  if((!nextAgendaUrl.isEmpty()&&!pipAgendaEndpoint(nextAgendaUrl.c_str()))||
     (!nextAgendaKey.isEmpty()&&!pipAgendaToken(nextAgendaKey.c_str()))||
     (nextAgendaEnabled&&(nextAgendaUrl.isEmpty()||nextAgendaKey.isEmpty()))){
   server.send(400,"text/plain; charset=utf-8","Agenda: serve il collegamento Google che termina in /exec e la chiave di 64 caratteri. Non usare la password Google.");return;
  }
  agendaUrl=nextAgendaUrl;agendaToken=nextAgendaKey;agendaEnabled=nextAgendaEnabled;leadMinutes=constrain(server.arg("lead").toInt(),1,60);eveningEnabled=server.hasArg("night");
  agenda={};experience.automaticAgain();if(page>=pageCount())page=0;
  bool reconnect=nextSSID!=ssid||!nextPass.isEmpty();
  if(nextSSID!=ssid&&nextPass.isEmpty())password="";else if(!nextPass.isEmpty())password=nextPass;
  ssid=nextSSID;city=nextCity;brightness=constrain(server.arg("light").toInt(),10,100);
  timerMinutes=constrain(server.arg("minutes").toInt(),1,180);intervalSec=constrain(server.arg("interval").toInt(),5,60);
  automatic=server.hasArg("auto");motion=server.hasArg("motion");flip=server.hasArg("flip");
  if(!timer.running)timer.reset(timerMinutes);
  savePreferences();panel->setRotation(flip?3:1);ledcWrite(BACKLIGHT,brightness*255/100);
  unsigned long epoch=strtoul(server.arg("epoch").c_str(),nullptr,10);
  if(epoch>1704067200UL&&epoch<4102444800UL){struct timeval tv={(time_t)epoch,0};settimeofday(&tv,nullptr);syncRTC();}
  configGeneration++;weather={};queueLocation();dirty=true;
  if(reconnect){WiFi.disconnect(false);ntpStarted=false;if(ssid.length())WiFi.begin(ssid.c_str(),password.c_str());}
  server.sendHeader("Location","/");server.send(303);
 });
 server.on("/timer",HTTP_POST,[]{
  if(!authorised())return;
  if(server.arg("action")=="restart")restartTimer(timerMinutes,millis());
  else if(server.arg("action")=="reset")resetFocus(timerMinutes,millis());else timer.toggle(timerMinutes,millis());
  page=3;pageAt=millis();dirty=true;server.sendHeader("Location","/");server.send(303);
 });
 server.onNotFound([]{server.sendHeader("Location","http://192.168.4.1/");server.send(302);});
}
void openSettings(){
 if(!ap){
  WiFi.mode(WIFI_AP_STA);IPAddress ip(192,168,4,1);WiFi.softAPConfig(ip,ip,IPAddress(255,255,255,0));
  ap=WiFi.softAP(apName.c_str(),apPassword.c_str(),1,false,2);
  if(ap){dns.start(53,"*",ip);server.begin();}
 }
 apActivity=millis();dirty=true;
}
void closeSettings(){
 if(ap){server.stop();dns.stop();WiFi.softAPdisconnect(true);WiFi.mode(WIFI_STA);ap=false;}
 pageAt=millis();dirty=true;
}

void render(uint32_t now){
 PipFace target=pipFace(facePose);
 float t=fminf(1.f,(now-faceAt)/650.f);float eased=t*t*(3-2*t);
 float PipFace::* members[]={&PipFace::open,&PipFace::arch,&PipFace::asym,&PipFace::smile,
  &PipFace::mouthO,&PipFace::blush,&PipFace::tilt,&PipFace::y,&PipFace::look,&PipFace::sweet,&PipFace::brow};
 for(auto member:members)faceCurrent.*member=faceFrom.*member+(target.*member-faceFrom.*member)*eased;
 int eye=motion&&imuOK?lroundf(motionTracker.look()):0;
 if(facePose==PipPose::Calm&&abs(eye)<2){uint32_t phase=now%20000;
  if(phase>=15000&&phase<=17000)eye=lroundf(sinf((phase-15000)*.0015707963f)*4);
 }
 bool blink=(now%5300)<125&&(facePose==PipPose::Calm||facePose==PipPose::Curious);
 static int previousEye=999;static bool previousBlink=false,previousWifi=false,previousTransition=false,previousStale=false;
 static time_t previousMinute=-1;static uint32_t previousTimer=0;static PipPose previousPose=PipPose::Calm;
 time_t sec=time(nullptr);uint32_t timerSecond=(timer.remaining+999)/1000;bool transition=t<1;
 bool connected=WiFi.status()==WL_CONNECTED;
 bool stale=weather.failed||!connected||!validClock()||sec-weather.measured>1800;
 static bool previousNight=false;
 bool changed=dirty||wild||nightMode!=previousNight||connected!=previousWifi||
  (!ap&&page==0&&(eye!=previousEye||blink!=previousBlink||facePose!=previousPose||transition||previousTransition))||
  (!ap&&(page==1||page==4||(page==0&&nightMode))&&sec/60!=previousMinute)||(!ap&&page==2&&stale!=previousStale)||(!ap&&page==3&&timerSecond!=previousTimer);
 if(!changed)return;
 uint32_t began=millis();
 previousNight=nightMode;previousEye=eye;previousBlink=blink;previousWifi=connected;previousMinute=sec/60;previousTimer=timerSecond;
 previousPose=facePose;previousTransition=transition;previousStale=stale;
 if(ap){
  screen.settings(apName.c_str(),apPassword.c_str(),connected);
 }else if(wild){
  PipFace shown=pipWildFace(now-wildAt);if(flip){shown.look=-shown.look;shown.tilt=-shown.tilt;}screen.face(shown);
 }else if(page==0&&nightMode){
  struct tm local;localtime_r(&sec,&local);char hour[12];snprintf(hour,sizeof(hour),"%02d:%02d",local.tm_hour,local.tm_min);screen.evening(hour);
 }else if(page==0){
  PipFace shown=faceCurrent;shown.look+=eye;if(flip){shown.look=-shown.look;shown.tilt=-shown.tilt;}
  screen.face(shown,blink);
 }else if(page==1){
  if(validClock()){
   struct tm local;localtime_r(&sec,&local);char hour[12],date[40];
   const char* days[]={"DOMENICA","LUNEDÌ","MARTEDÌ","MERCOLEDÌ","GIOVEDÌ","VENERDÌ","SABATO"};
   const char* months[]={"gennaio","febbraio","marzo","aprile","maggio","giugno","luglio","agosto","settembre","ottobre","novembre","dicembre"};
   snprintf(hour,sizeof(hour),"%02d:%02d",local.tm_hour,local.tm_min);
   snprintf(date,sizeof(date),"%d %s",local.tm_mday,months[local.tm_mon]);screen.clock(hour,days[local.tm_wday],date);
  }else screen.message("Ora da impostare",connected?"Sincronizzazione...":"Wi-Fi non collegato");
 }else if(page==2){
  if(weather.valid){
   String place=lcdLabel(weather.place,64);int comma=place.indexOf(',');if(comma>=0)place=place.substring(0,comma);
   struct tm local;localtime_r(&weather.measured,&local);char stamp[40]={};
   if(stale)snprintf(stamp,sizeof(stamp),"Ultimo dato %02d:%02d",local.tm_hour,local.tm_min);
   screen.weather(place.c_str(),lroundf(weather.temperature),pipWeather(weather.code),weather.humidity,lroundf(weather.wind),stamp);
  }else{
   screen.message(city.isEmpty()?"Città non impostata":weather.locationNotFound?"Città non trovata":"Meteo in attesa",
    weather.locationNotFound?"Località non riconosciuta":!connected?"Wi-Fi non collegato":weather.failed?"Servizio non disponibile":"Aggiornamento...");
  }
 }else if(page==3){
  char ending[32]={};if(timer.running&&validClock()){
   time_t finish=sec+(timer.remaining+999)/1000;struct tm local;localtime_r(&finish,&local);
   snprintf(ending,sizeof(ending),"fine alle %02d:%02d",local.tm_hour,local.tm_min);
  }
  screen.timer(timer.remaining,timer.total,timer.running,timer.done,ending);
 }else pipDrawAgenda(screen,agenda,sec,connected);
 gfx->flush();dirty=false;paintMs=millis()-began;paintCount++;
}

void setup(){
 USBSerial.begin(115200);
 pinMode(ENABLE,OUTPUT);digitalWrite(ENABLE,HIGH);pinMode(BUZZER,OUTPUT);digitalWrite(BUZZER,LOW);
 pinMode(PWR,INPUT);input.begin(digitalRead(PWR)==LOW,millis());
 prefs.begin("pip_public",false);ssid=prefs.getString("ssid","");password=prefs.getString("pass","");city=prefs.getString("city","");
 agendaUrl=prefs.getString("agenda_url","");agendaToken=prefs.getString("agenda_key","");agendaEnabled=prefs.getBool("agenda_on",false);leadMinutes=constrain(prefs.getUShort("lead_min",10),1,60);eveningEnabled=prefs.getBool("night_on",true);
 automatic=prefs.getBool("studio_auto",true);motion=prefs.getBool("motion",true);flip=prefs.getBool("flip",false);
 brightness=constrain(prefs.getUChar("light",65),10,100);intervalSec=constrain(prefs.getUChar("interval",12),5,60);
 timerMinutes=constrain(prefs.getUShort("minutes",25),1,180);timer.reset(timerMinutes);
 String secret=prefs.getString("apkey","");if(secret.length()!=12){char b[16];snprintf(b,sizeof(b),"pip-%08lX",(unsigned long)esp_random());secret=b;prefs.putString("apkey",secret);}
 apPassword=secret;char name[20];snprintf(name,sizeof(name),"PIP-%04X",(unsigned)(ESP.getEfuseMac()&0xFFFF));apName=name;
 char token[20];snprintf(token,sizeof(token),"%08lX%08lX",(unsigned long)esp_random(),(unsigned long)esp_random());csrf=token;
 displayOK=gfx->begin();panel->setRotation(flip?3:1);ledcAttach(BACKLIGHT,5000,8);ledcWrite(BACKLIGHT,displayOK?brightness*255/100:0);
 setenv("TZ",TZ_ROME,1);tzset();Wire.begin(11,10);
 rtcOK=rtc.begin(Wire,PCF85063_SLAVE_ADDRESS,11,10);restoreRTC();
 imuOK=imu.begin(Wire,QMI8658_L_SLAVE_ADDRESS,11,10);
 if(imuOK){imu.configAccelerometer(SensorQMI8658::ACC_RANGE_4G,SensorQMI8658::ACC_ODR_125Hz,SensorQMI8658::LPF_MODE_0,true,false);imu.enableAccelerometer();}
 WiFi.mode(WIFI_STA);WiFi.setAutoReconnect(true);if(ssid.length())WiFi.begin(ssid.c_str(),password.c_str());
 setupRoutes();configQueue=xQueueCreate(1,sizeof(NetConfig));resultQueue=xQueueCreate(1,sizeof(Weather));agendaQueue=xQueueCreate(1,sizeof(PipAgenda));
 if(configQueue&&resultQueue&&agendaQueue){networkStarted=xTaskCreatePinnedToCore(networkTask,"pip-network",24576,nullptr,1,nullptr,0)==pdPASS;if(networkStarted)queueLocation();}
 pageAt=millis();if(ssid.isEmpty())openSettings();if(displayOK)render(millis());
 USBSerial.printf("PIP Public 1.0.0-rc2: display=%d landscape=%dx%d imu=%d rtc=%d\n",displayOK,gfx->width(),gfx->height(),imuOK,rtcOK);
}

void loop(){
 // Diagnostica locale: 's' stato, 'w' nuova richiesta. Nessuna password/località.
 while(USBSerial.available()){
  int c=USBSerial.read();if(c=='w')queueLocation();
  if(c=='f'){page=0;pageAt=millis();experience.select(pageAt);dirty=true;}
  if(c=='t')restartTimer(1,millis());
  if(c=='s'||c=='w'||c=='f'||c=='t')reportStatus();
 }
 uint32_t now=millis();PipInput::Event e=input.update(digitalRead(PWR)==LOW,now);
 if(e==PipInput::Long){if(!ap&&page==3)resetFocus(timerMinutes,now);else openSettings();}
 else if(e==PipInput::Single){
  if(ap)closeSettings();else{if(timer.done){timer.done=false;page=0;}else page=(page+1)%pageCount();experience.select(now);pageAt=now;dirty=true;}
 }else if(e==PipInput::Double){
  if(!ap&&page==3)timer.toggle(timerMinutes,now);else if(!ap){automatic=!automatic;prefs.putBool("studio_auto",automatic);experience.automaticAgain();pageAt=now;}dirty=true;
 }
 if(input.busy()&&wild){wild=false;dirty=true;}
 if(timer.update(now)){wild=false;page=3;dirty=true;}
 if(ap){
  dns.processNextRequest();server.handleClient();
  // Le richieste HTTP e openSettings() possono aver aggiornato apActivity
  // dopo il millis() iniziale del loop: campionare DOPO queste operazioni.
  now=millis();
  if(pipIntervalReached(now,apActivity,600000UL))closeSettings();
 }
 // Anche closeSettings() aggiorna pageAt: evitare lo stesso problema sulle pagine.
 now=millis();
 if(WiFi.status()==WL_CONNECTED&&!ntpStarted){configTzTime(TZ_ROME,"pool.ntp.org","time.cloudflare.com");ntpStarted=true;dirty=true;}
 if(!ssid.isEmpty()&&WiFi.status()!=WL_CONNECTED&&now-lastRetry>30000){lastRetry=now;WiFi.reconnect();}
 Weather incoming;
 if(resultQueue&&xQueueReceive(resultQueue,&incoming,0)==pdTRUE&&incoming.generation==configGeneration){
  if(incoming.valid)weather=incoming;else{weather.failed=true;weather.locationNotFound=incoming.locationNotFound;}dirty=true;
 }
 PipAgenda incomingAgenda;
 if(agendaQueue&&xQueueReceive(agendaQueue,&incomingAgenda,0)==pdTRUE&&incomingAgenda.generation==configGeneration){
  if(incomingAgenda.valid)agenda=incomingAgenda;else{agenda.failed=true;agenda.error=incomingAgenda.error;}dirty=true;
 }
 if(imuOK&&now-lastSample>=40){lastSample=now;
  if(imu.getDataReady()&&imu.getAccelerometer(acc.x,acc.y,acc.z))motionTracker.sample(acc.x,acc.y,acc.z,now);
 }
 nightMode=isNight();
 PipPose nextPose=motion&&imuOK?motionTracker.pose(now):PipPose::Calm;
 if(nextPose==PipPose::Sleepy&&!nightMode)nextPose=PipPose::Calm;
 const bool newReaction=motionTracker.reactions()!=lastReactions;
 lastReactions=motionTracker.reactions();
 if(motion&&imuOK&&!ap&&!timer.done&&!input.busy()&&newReaction&&(!wildEver||pipIntervalReached(now,lastWildAt,5000))){
  wild=true;wildEver=true;wildAt=lastWildAt=now;dirty=true;
 }
 if(wild&&pipIntervalReached(now,wildAt,PIP_WILD_MS)){
  wild=false;experience.phaseAt=now;if(experience.manual)experience.manualAt=now;dirty=true;
 }
 if(nextPose!=facePose){faceFrom=faceCurrent;facePose=nextPose;faceAt=now;if(page==0)dirty=true;}
 if(!ap&&!wild&&!timer.done&&page!=3){
  int nearby=pipNearbyAppointment(agenda,time(nullptr),agendaConfigured(),WiFi.status()==WL_CONNECTED,leadMinutes);
  uint8_t wanted=experience.desired(now,agenda,nearby,page,automatic,intervalSec,input.busy());
  if(timer.running&&!experience.manual&&!input.busy())wanted=3;
  if(wanted!=page){page=wanted;pageAt=now;dirty=true;}
 }
 static int previousLight=-1;int light=nightMode&&!ap&&!wild&&page==0?(brightness<20?brightness:20):brightness;
 if(light!=previousLight){ledcWrite(BACKLIGHT,displayOK?light*255/100:0);previousLight=light;}
 if(now-lastRtc>60000){lastRtc=now;syncRTC();}
 if(displayOK&&now-lastPaint>=50){lastPaint=now;render(now);}
 delay(3);
}
