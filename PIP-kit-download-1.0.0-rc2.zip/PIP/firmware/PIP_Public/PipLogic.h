#pragma once
#include <stdint.h>

// Per intervalli < 2^31 ms. Un'attività aggiornata dopo il campione di `now`
// non è inattività: la sottrazione unsigned da sola sembrerebbe quasi 49 giorni.
inline bool pipIntervalReached(uint32_t now,uint32_t since,uint32_t interval){
 uint32_t elapsed=now-since;
 return elapsed<0x80000000UL&&elapsed>=interval;
}

class PipInput {
public:
 enum Event {None,Single,Double,Long};
 void begin(bool p,uint32_t now){raw=stable=p;changed=pressedAt=now;armed=!p;pending=fired=false;}
 Event update(bool p,uint32_t now){
  Event out=None;
  if(p!=raw){raw=p;changed=now;}
  if(now-changed>=35&&stable!=raw){
   stable=raw;
   if(stable){pressedAt=now;fired=false;}
   else if(!armed)armed=true;
   else if(!fired&&now-pressedAt<800){
    if(pending&&now-released<420){pending=false;out=Double;}
    else{if(pending)out=Single;pending=true;released=now;}
   }
  }
  if(stable&&armed&&!fired&&now-pressedAt>=1800){fired=true;pending=false;out=Long;}
  if(pending&&!stable&&now-released>=420){pending=false;out=Single;}
  return out;
 }
 bool held() const{return raw||stable;}
 bool busy() const{return raw||stable||pending;}
private:
 bool raw=false,stable=false,armed=true,pending=false,fired=false;
 uint32_t changed=0,pressedAt=0,released=0;
};

class PipTimer {
public:
 uint32_t total=25*60000UL,remaining=25*60000UL;bool running=false,done=false;
 void reset(uint16_t minutes){remaining=total=(uint32_t)minutes*60000UL;running=done=false;}
 void restart(uint16_t minutes,uint32_t now){reset(minutes);stamp=now;running=true;}
 void toggle(uint16_t minutes,uint32_t now){if(remaining==0)reset(minutes);running=!running;stamp=now;done=false;}
 bool update(uint32_t now){
  if(!running)return false;
  uint32_t dt=now-stamp;stamp=now;
  if(dt>=remaining){remaining=0;running=false;done=true;return true;}
  remaining-=dt;return false;
 }
private:uint32_t stamp=0;
};

inline const char* pipWeather(int code){
 if(code==0)return "Sereno";
 if(code==1)return "Poco nuvoloso";
 if(code==2)return "Parz. nuvoloso";
 if(code==3)return "Nuvoloso";
 if(code==45||code==48)return "Nebbia";
 if((code>=51&&code<=57))return "Pioviggine";
 if((code>=61&&code<=67)||(code>=80&&code<=82))return "Pioggia";
 if((code>=71&&code<=77)||code==85||code==86)return "Neve";
 if(code>=95&&code<=99)return "Temporale";
 return "Meteo";
}
