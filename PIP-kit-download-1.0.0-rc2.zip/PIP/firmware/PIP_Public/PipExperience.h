#pragma once
#include "PipAgenda.h"
#include "PipLogic.h"
#include "PipMotion.h"

// Conserva l'identità delle pagine di v1.3/v1.4. Il riposo non è un carosello.
inline int pipNearbyAppointment(const PipAgenda& agenda,time_t now,bool configured,bool connected,uint16_t leadMinutes=10){
 if(!configured||now<1704067200||pipAgendaStale(agenda,now,connected))return -1;
 int i=pipAgendaSelection(agenda,now);
 if(i<0||agenda.events[i].allDay)return -1;
 return agenda.events[i].start<=now+(time_t)leadMinutes*60?i:-1;
}

struct PipExperience {
 bool manual=false,context=false;uint32_t manualAt=0,phaseAt=0;uint8_t phase=0;
 char eventId[25]={};time_t eventStart=0;
 void select(uint32_t now){manual=true;manualAt=now;}
 void automaticAgain(){manual=false;context=false;}
 // Il timer e le impostazioni vengono gestiti dal chiamante e hanno precedenza.
 uint8_t desired(uint32_t now,const PipAgenda& agenda,int index,uint8_t current,bool automatic,uint8_t intervalSec,bool inputBusy){
  if(inputBusy||!automatic)return current;
  if(manual){if(!pipIntervalReached(now,manualAt,20000UL))return current;manual=false;context=false;}
  if(index<0){context=false;return 0;}
  const auto& e=agenda.events[index];
  if(!context||strcmp(eventId,e.id)||eventStart!=e.start){
   context=true;strcpy(eventId,e.id);eventStart=e.start;phase=0;phaseAt=now;
  }else if(pipIntervalReached(now,phaseAt,(uint32_t)intervalSec*1000)){
   phase=(phase+1)%3;phaseAt=now;
  }
  const uint8_t pages[]={4,1,2};return pages[phase];
 }
};

constexpr uint32_t PIP_WILD_MS=2800;
inline PipFace pipWildFace(uint32_t age){
 PipFace p=pipFace(PipPose::Surprised);
 if(age<350){p.open=1.28f;p.y=-4;return p;}
 if(age<1850){
  float t=(age-350)*.001f;p.look=14*sinf(t*17);p.tilt=8*sinf(t*12);
  p.y=4*sinf(t*15);p.asym=.12f*sinf(t*9);p.open=1.02f+.17f*sinf(t*13);
  p.mouthO=.65f+.3f*sinf(t*8);return p;
 }
 p=pipFace(PipPose::Happy);float settle=fmaxf(0,1-(age-1850)/950.f);
 p.tilt=5*sinf((age-1850)*.012f)*settle;p.look=7*sinf((age-1850)*.015f)*settle;
 return p;
}

// Una pressione lunga torna alla durata impostata SENZA avviare il conteggio.
inline void pipResetFocus(PipTimer& timer,uint16_t minutes){timer.reset(minutes);}
