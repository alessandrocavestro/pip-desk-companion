#pragma once
#include <math.h>
#include <cJSON.h>
#include "PipAgenda.h"

inline bool pipAgendaInteger(cJSON* parent,const char* key,double& out){
 const cJSON* v=cJSON_GetObjectItemCaseSensitive(parent,key);
 if(!cJSON_IsNumber(v)||!isfinite(v->valuedouble)||floor(v->valuedouble)!=v->valuedouble)return false;
 out=v->valuedouble;return true;
}
inline bool pipAgendaText(const char* s,size_t capacity){
 if(!s||!s[0]||strlen(s)>=capacity)return false;
 const auto* p=(const unsigned char*)s;
 while(*p){
  if(*p<32||*p==127)return false;
  if(*p<128){++p;continue;}
  unsigned lead=*p++,need=0,cp=0,min=0;
  if(lead>=0xc2&&lead<=0xdf){need=1;cp=lead&31;min=0x80;}
  else if(lead>=0xe0&&lead<=0xef){need=2;cp=lead&15;min=0x800;}
  else if(lead>=0xf0&&lead<=0xf4){need=3;cp=lead&7;min=0x10000;}else return false;
  while(need--){if((*p&0xc0)!=0x80)return false;cp=(cp<<6)|(*p++&63);}
  if(cp<min||cp>0x10ffff||(cp>=0xd800&&cp<=0xdfff))return false;
 }return true;
}
inline PipAgendaError pipParseAgenda(const char* body,time_t now,PipAgenda& output){
 cJSON* doc=cJSON_ParseWithOpts(body,nullptr,true);if(!doc)return PipAgendaError::Invalid;
 auto parse=[&]()->PipAgendaError{
  if(!cJSON_IsObject(doc))return PipAgendaError::Invalid;
  if(!cJSON_IsTrue(cJSON_GetObjectItemCaseSensitive(doc,"ok"))){
   cJSON* error=cJSON_GetObjectItemCaseSensitive(doc,"error");
   if(cJSON_IsString(error)&&!strcmp(error->valuestring,"unauthorized"))return PipAgendaError::Unauthorized;
   return PipAgendaError::Unavailable;
  }
  double version,generated,until;
  if(!pipAgendaInteger(doc,"version",version)||version!=1||!pipAgendaInteger(doc,"generated",generated)||
     generated<1704067200||generated>4102444800.0||generated>now+300||now-generated>600||
     !pipAgendaInteger(doc,"until",until)||until<=generated||until>generated+8*86400)return PipAgendaError::Invalid;
  cJSON* events=cJSON_GetObjectItemCaseSensitive(doc,"events");
  if(!cJSON_IsArray(events)||cJSON_GetArraySize(events)>int(PIP_AGENDA_MAX))return PipAgendaError::Invalid;
  PipAgenda parsed;parsed.generated=time_t(generated);parsed.until=time_t(until);
  cJSON* item=nullptr;
  cJSON_ArrayForEach(item,events){
   auto str=[&](const char* key)->const char*{cJSON* v=cJSON_GetObjectItemCaseSensitive(item,key);return cJSON_IsString(v)?v->valuestring:nullptr;};
   const char *id=str("id"),*title=str("title"),*source=str("source");double start,end;
   cJSON* day=cJSON_GetObjectItemCaseSensitive(item,"all_day");
   if(!pipAgendaText(id,25)||strlen(id)!=24||!pipAgendaText(title,121)||!pipAgendaText(source,32)||!cJSON_IsBool(day)||
      !pipAgendaInteger(item,"start",start)||!pipAgendaInteger(item,"end",end)||start<0||end>4102444800.0||
      end<=start||end<=generated||start>=until)return PipAgendaError::Invalid;
   for(unsigned i=0;i<24;i++)if(!((id[i]>='0'&&id[i]<='9')||(id[i]>='a'&&id[i]<='f')))return PipAgendaError::Invalid;
   // User-defined source labels; byte length and UTF-8 were validated above.
   for(unsigned j=0;j<parsed.count;j++)if(!strcmp(parsed.events[j].id,id))return PipAgendaError::Invalid;
   auto& e=parsed.events[parsed.count++];strcpy(e.id,id);strcpy(e.title,title);strcpy(e.source,source);
   e.start=time_t(start);e.end=time_t(end);e.allDay=cJSON_IsTrue(day);
  }
  parsed.valid=true;output=parsed;return PipAgendaError::None;
 };
 const PipAgendaError result=parse();cJSON_Delete(doc);return result;
}
