#pragma once
#include <stdint.h>
#include <string.h>
#include <time.h>

constexpr unsigned PIP_AGENDA_MAX=20;
enum class PipAgendaError:uint8_t {None,Transport,Unauthorized,Unavailable,Invalid};
struct PipAppointment {
 char id[25],title[121],source[32];time_t start,end;bool allDay;
};
struct PipAgenda {
 bool valid=false,failed=false;uint8_t count=0;uint32_t generation=0;
 PipAgendaError error=PipAgendaError::None;
 time_t generated=0,until=0;PipAppointment events[PIP_AGENDA_MAX]={};
};
inline bool pipAgendaStale(const PipAgenda& a,time_t now,bool connected){
 return !a.valid||a.failed||!connected||now<a.generated-300||now-a.generated>600||now>=a.until;
}
inline int pipAgendaSelection(const PipAgenda& a,time_t now){
 int active=-1,next=-1,day=-1;
 for(unsigned i=0;i<a.count;i++){
  const auto& e=a.events[i];if(e.end<=now)continue;
  if(e.allDay){if(day<0||e.start<a.events[day].start)day=i;continue;}
  if(e.start<=now){if(active<0||e.start<a.events[active].start)active=i;}
  else if(next<0||e.start<a.events[next].start)next=i;
 }
 return active>=0?active:next>=0?next:day;
}
struct PipAgendaAlerts {
 char ids[PIP_AGENDA_MAX][25]={};time_t starts[PIP_AGENDA_MAX]={};
 void clear(){memset(ids,0,sizeof(ids));memset(starts,0,sizeof(starts));}
 int pending(const PipAgenda& a,time_t now)const{
  int best=-1;
  for(unsigned i=0;i<a.count;i++){
   const auto& e=a.events[i];if(e.allDay||e.start<=now||e.start-now>600)continue;
   bool seen=false;for(unsigned j=0;j<PIP_AGENDA_MAX;j++)if(starts[j]==e.start&&!strcmp(ids[j],e.id))seen=true;
   if(!seen&&(best<0||e.start<a.events[best].start))best=i;
  }return best;
 }
 void mark(const PipAppointment& e,time_t now){
  unsigned slot=0;
  for(unsigned j=0;j<PIP_AGENDA_MAX;j++)if(starts[j]<starts[slot])slot=j;
  memcpy(ids[slot],e.id,sizeof(ids[slot]));starts[slot]=e.start;
 }
};
inline bool pipAgendaToken(const char* s){
 if(strlen(s)!=64)return false;for(unsigned i=0;i<64;i++)if(!((s[i]>='0'&&s[i]<='9')||(s[i]>='a'&&s[i]<='f')))return false;return true;
}
inline bool pipAgendaEndpoint(const char* s){
 const char* prefix="https://script.google.com/macros/s/";
 size_t p=strlen(prefix),n=strlen(s);if(n<=p+5||n>=256||strncmp(s,prefix,p)||strcmp(s+n-5,"/exec"))return false;
 for(size_t i=p;i<n-5;i++)if(!((s[i]>='a'&&s[i]<='z')||(s[i]>='A'&&s[i]<='Z')||(s[i]>='0'&&s[i]<='9')||s[i]=='-'||s[i]=='_'))return false;
 return true;
}
inline bool pipAgendaRedirect(const char* s){
 const char* prefix="https://script.googleusercontent.com/";
 return strlen(s)<4096&&!strncmp(s,prefix,strlen(prefix))&&!strchr(s,'\r')&&!strchr(s,'\n');
}
